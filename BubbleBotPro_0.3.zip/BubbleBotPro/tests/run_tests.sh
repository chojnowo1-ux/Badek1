#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
OUT=tests/bin
mkdir -p "$OUT"
javac -d "$OUT" app/src/main/java/pl/bubblebot/pro/Board.java \
  app/src/main/java/pl/bubblebot/pro/BoardDetector.java \
  app/src/main/java/pl/bubblebot/pro/ShotPlanner.java \
  app/src/main/java/pl/bubblebot/pro/MenuDetector.java \
  tests/AdaptiveColorTest.java tests/GeometryRegressionTest.java tests/FloorGlowTest.java tests/DetectorTest.java tests/MenuTest.java tests/SpeedBench.java
java -Djava.awt.headless=true -cp "$OUT" AdaptiveColorTest
java -Djava.awt.headless=true -cp "$OUT" GeometryRegressionTest
java -Djava.awt.headless=true -cp "$OUT" FloorGlowTest
if [ "$#" -gt 0 ]; then
  java -Djava.awt.headless=true -cp "$OUT" DetectorTest "$@"
fi
