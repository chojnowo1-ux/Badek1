#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)";trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" "$DIR/app/src/main/java/pl/bubblebot/pro/BoardState.java" "$DIR/app/src/main/java/pl/bubblebot/pro/TrajectoryPlanner.java" "$DIR/tests/PlannerTest.java" "$DIR/tests/FrameTest.java"
java -cp "$TMP" PlannerTest
java -cp "$TMP" FrameTest
