import pl.bubblebot.pro.*;
public class FrameTest {
 public static void main(String[] args) {
 BoardState b=new BoardState();
 int[][] data= new int[][]{
{3,3,1,5,6,6,4,3,3,5,6,4,6},
{6,4,3,1,3,3,1,3,5,6,6,4,0},
{2,5,5,6,6,4,2,1,3,5,1,3,4},
{5,6,5,4,4,6,3,6,3,5,3,6,0},
{6,6,3,4,2,2,2,5,6,1,2,6,4},
{2,4,5,4,4,6,5,3,2,4,6,2,0},
{1,3,5,1,2,4,1,3,4,4,3,5,1},
{3,2,2,5,3,5,6,4,6,5,3,5,0},
{0,5,2,1,1,6,5,6,1,4,2,4,5},
{0,0,6,0,4,2,3,6,3,4,6,3,0},
{0,0,0,0,6,6,2,3,5,3,5,4,5},
{0,0,0,3,3,0,6,3,6,3,1,5,0},
{0,0,0,5,5,6,0,6,2,6,6,4,4},
{0,0,5,6,0,2,0,1,3,2,6,4,0},
{0,0,0,0,6,2,0,6,6,2,1,6,6},
{0,0,0,0,1,0,1,0,4,2,5,3,0},
{0,0,0,0,0,0,6,0,2,0,4,2,4},
{0,0,0,0,0,0,0,0,2,0,6,2,0},
{0,0,0,0,0,0,0,0,0,0,0,2,6},
{0,0,0,0,0,0,0,0,0,0,3,4,0},
{0,0,0,0,0,0,0,0,0,0,0,2,3},
{0,0,0,0,0,0,0,0,0,0,0,3,0},
{0,0,0,0,0,0,0,0,0,0,0,0,5},
{0,0,0,0,0,0,0,0,0,0,0,0,0}
};
 for(int r=0;r<BoardState.ROWS;r++)System.arraycopy(data[r],0,b.cells[r],0,BoardState.COLS);
 b.current=5;b.next=2;b.recalcHash();
 long start=System.nanoTime();TrajectoryPlanner.Shot s=TrajectoryPlanner.choose(b);
 if(s==null)throw new AssertionError("shot missing");
 System.out.printf("Real screenshot test: cells=%d, danger=%.0f, chosen angle=%.1f, target=(%d,%d), popped=%d dropped=%d, score=%.1f, time=%.0f ms%n", b.count,b.deepestY(),s.angle*180/Math.PI,s.row,s.col,s.popped,s.dropped,s.score,(System.nanoTime()-start)/1e6);
 b.current=BoardState.YELLOW; b.recalcHash();TrajectoryPlanner.Shot next=TrajectoryPlanner.choose(b); System.out.printf("Next YELLOW: angle=%.1f, target=(%d,%d), popped=%d, dropped=%d, score=%.1f%n",next.angle*180/Math.PI,next.row,next.col,next.popped,next.dropped,next.score);
 if(next.score < s.score+850 || next.dropped<3)throw new AssertionError("Expected alternate YELLOW rescue to outrank BLUE");
 if(Double.isNaN(s.score)||s.row<0||s.row>=24)throw new AssertionError("invalid shot");
 }
}
