package pl.bubblebot.pro;

/** Regression: clear the immediate bottom danger before high-value top matches. */
public final class SurvivalPlannerTest {
  private static void check(boolean yes,String reason){if(!yes)throw new AssertionError(reason);}
  public static void main(String[] args){
    Board b=new Board(300,0);
    // Attractive six-green cluster near the roof (high raw score).
    for(int r=0;r<3;r++)for(int c=2;c<4;c++)b.cells[r][c]=Board.GREEN;
    // Anchored red chain hanging down on the right.
    for(int r=0;r<20;r++)b.cells[r][9]=Board.RED;
    // Two critical low greens (matching colour) close to the loss line.
    b.cells[20][9]=Board.GREEN;
    b.cells[21][9]=Board.GREEN;
    ShotPlanner.Shot shot=new ShotPlanner().choose(b,Board.GREEN);
    check(shot!=null,"Planner did not return a shot");
    check(shot.removed>=3,"Critical green shot must remove balls, got "+shot.removed);
    check(shot.after.cells[20][9]==Board.EMPTY && shot.after.cells[21][9]==Board.EMPTY,
       "Emergency shot must clear two lowest greens, not merely score points higher up");
    check(ShotPlanner.boardDanger(shot.after)<ShotPlanner.boardDanger(b),
       "Survival planner must reduce danger");
    System.out.printf("PASS survival target: angle=%.2f removed=%d dropped=%d score=%.1f%n",shot.angleDegrees,shot.removed,shot.dropped,shot.score);

    Board safe=new Board(300,0);safe.cells[0][2]=Board.BLUE;
    check(ShotPlanner.boardDanger(b)>ShotPlanner.boardDanger(safe),
       "Low hanging bubbles must have higher danger than top bubbles");
    check(ShotPlanner.deepestY(b)>ShotPlanner.deepestY(safe),
       "Deepest-bubble check must reflect physical positions");
    System.out.println("PASS risk evaluation and emergency matching");
  }
}
