import pl.bubblebot.pro.BoardState;
import pl.bubblebot.pro.TrajectoryPlanner;

public class PlannerTest {
  static void require(boolean b,String m){if(!b)throw new AssertionError(m);}
  public static void main(String[] a){
    BoardState b=new BoardState();
    b.cells[0][6]=BoardState.BLUE;b.cells[1][5]=BoardState.BLUE;b.cells[1][6]=BoardState.RED;
    b.current=BoardState.BLUE;b.recalcHash();
    TrajectoryPlanner.Shot s=TrajectoryPlanner.choose(b);
    require(s!=null,"must find shot");
    require(s.popped>=3,"must prioritize available triple, got " + s.popped);
    require(s.col>=0,"col");
    BoardState c=new BoardState();c.cells[0][0]=BoardState.GREEN;c.cells[1][0]=BoardState.GREEN;c.current=BoardState.GREEN;c.recalcHash();
    TrajectoryPlanner.Shot t=TrajectoryPlanner.choose(c);require(t!=null&&t.popped>=3,"edge triple");
    BoardState d=new BoardState();d.current=BoardState.RED;d.recalcHash();require(TrajectoryPlanner.choose(d)==null,"empty must not tap");
    // New ceiling rows flip the staggered hex pattern; both offsets must have
    // valid symmetrical adjacency and survive a deep copy.
    BoardState p=new BoardState(); p.firstRowOffset=1;
    require(BoardState.cx(p,0,0)==64,"odd-first row starts at x64");
    require(BoardState.cx(p,1,0)==32,"following row starts at x32");
    p.cells[0][0]=BoardState.GREEN;p.cells[1][0]=BoardState.GREEN;
    require(p.copy().firstRowOffset==1,"copy must retain first-row offset");
    require(p.neighbors(0,0)[2][0]==-1,"top neighbor row");
    BoardState falling=new BoardState();
    falling.cells[0][2]=BoardState.GREEN;falling.cells[1][1]=BoardState.BLUE;
    falling.cells[22][5]=BoardState.RED;falling.cells[23][4]=BoardState.PINK;
    falling.pruneDetached();
    require(falling.cells[0][2]==BoardState.GREEN && falling.cells[1][1]==BoardState.BLUE,
      "ceiling-connected groups must survive");
    require(falling.cells[22][5]==0 && falling.cells[23][4]==0,
      "falling balls / aim dots must be discarded");
    System.out.println("OK: matching, geometry for both stagger orientations, empty board");
  }
}
