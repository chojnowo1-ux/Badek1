import pl.bubblebot.pro.BoardState;
import pl.bubblebot.pro.TrajectoryPlanner;

public class PlannerTest {
  static void require(boolean b,String m){if(!b)throw new AssertionError(m);}
  public static void main(String[] a){
    BoardState b=new BoardState();
    b.cells[0][6]=BoardState.BLUE;b.cells[1][5]=BoardState.BLUE;b.cells[1][6]=BoardState.RED;
    b.current=BoardState.BLUE;b.recalcHash();
    TrajectoryPlanner.Shot s=TrajectoryPlanner.choose(b);
    require(s!=null,"must find shot");
    require(s.popped>=3,"must prioritize available triple, got " + s.popped);
    require(s.col>=0,"col");
    BoardState c=new BoardState();c.cells[0][0]=BoardState.GREEN;c.cells[1][0]=BoardState.GREEN;c.current=BoardState.GREEN;c.recalcHash();
    TrajectoryPlanner.Shot t=TrajectoryPlanner.choose(c);require(t!=null&&t.popped>=3,"edge triple");
    BoardState d=new BoardState();d.current=BoardState.RED;d.recalcHash();require(TrajectoryPlanner.choose(d)==null,"empty must not tap");
    System.out.println("OK: matching, edge geometry, empty board");
  }
}
