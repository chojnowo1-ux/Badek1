import pl.bubblebot.pro.Board;
import pl.bubblebot.pro.BoardDetector;
import pl.bubblebot.pro.ShotPlanner;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/** Catch accumulated Y drift: older row spacing lost the bottom half. */
public final class GeometryRegressionTest {
  public static void main(String[] args) {
    BufferedImage im=new BufferedImage(864,1920,BufferedImage.TYPE_INT_RGB);
    Graphics2D g=im.createGraphics();
    g.setColor(new Color(25,4,71));g.fillRect(0,0,864,1920);
    final float[] hues={4/360f,48/360f,115/360f,180/360f,212/360f,305/360f};
    Board trueBoard=new Board(308,1);
    int genuine=0;
    for(int r=0;r<21;r++)for(int c=0;c<Board.COLS;c++){
      if(!trueBoard.valid(r,c) || (r>16 && c<3))continue;
      int hue=(r*5+c)%6;
      g.setColor(Color.getHSBColor(hues[hue],0.83f,0.97f));
      g.fillOval((int)trueBoard.x(r,c)-27,(int)trueBoard.y(r)-27,54,54);
      genuine++;
    }
    // Actual game has a red/orange glow, not a bubble, near the danger line.
    g.setColor(new Color(201,9,34));g.fillRect(16,1572,832,36);
    g.setColor(Color.getHSBColor(hues[1],0.85f,0.97f));g.fillOval(404,1695,56,56);
    g.setColor(Color.getHSBColor(hues[2],0.85f,0.97f));g.fillOval(358,1737,36,36);
    g.dispose();
    BoardDetector.Detection d=new BoardDetector(new BoardDetector.Pixels(){
      public int width(){return im.getWidth();}
      public int height(){return im.getHeight();}
      public int argb(int x,int y){return im.getRGB(x,y);}
    }).detect();
    if(!d.playable() || d.count<genuine*0.88 || d.paletteSize!=6)
      throw new AssertionError("Dense board read: "+d.count+"/"+genuine+", palette="+d.paletteSize);
    if(Math.abs(d.board.topY-308)>18 || d.board.phase!=1)
      throw new AssertionError("Wrong fitted grid: top="+d.board.topY+" phase="+d.board.phase);
    ShotPlanner.Shot shot=new ShotPlanner().choose(d.board,d.current);
    if(shot==null || !Double.isFinite(shot.targetX))throw new AssertionError("No valid aim");
    System.out.println("PASS dense/low board grid: "+d.count+"/"+genuine+" balls, 6 colours, topY="+d.board.topY);
  }
}
