import pl.bubblebot.pro.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
public class MenuTest {
 public static void main(String[] args)throws Exception {
  for(String s:args){BufferedImage b=ImageIO.read(new File(s));
   BoardDetector.Pixels p=new BoardDetector.Pixels(){
    public int width(){return b.getWidth();} public int height(){return b.getHeight();}
    public int argb(int x,int y){return b.getRGB(x,y);}};
   System.out.println(s+": replayMenu="+MenuDetector.replayVisible(p));
  }
 }
}
