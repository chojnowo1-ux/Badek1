import pl.bubblebot.pro.*;import java.awt.image.BufferedImage;import javax.imageio.ImageIO;import java.io.File;import java.lang.reflect.Method;
public class DiagColors{
 public static void main(String[] a)throws Exception{
  BufferedImage im=ImageIO.read(new File(a[0]));
  BoardDetector.Pixels p=new BoardDetector.Pixels(){public int width(){return im.getWidth();}public int height(){return im.getHeight();}public int argb(int x,int y){return im.getRGB(x,y);}};
  BoardDetector det=new BoardDetector(p);BoardDetector.Detection d=det.detect();
  Method m=BoardDetector.class.getDeclaredMethod("hueAt",double.class,double.class,boolean.class);m.setAccessible(true);
  for(int row=0;row<24;row++){
   int valid=0,occupied=0;
   System.out.printf("row %02d ",row);
   for(int col=0;col<13;col++) { if(!d.board.valid(row,col))continue;
    double h=(double)m.invoke(det,d.board.x(row,col),d.board.y(row),false);
    int c=d.board.cells[row][col];
    if(h>=0)valid++;if(c>=0)occupied++;
    System.out.printf("%s ",h<0?" --":String.format("%3d",(int)h));
   }
   System.out.printf("  => good=%d mapped=%d%n",valid,occupied);
  }
 }
}
