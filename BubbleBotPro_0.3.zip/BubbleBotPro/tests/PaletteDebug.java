import pl.bubblebot.pro.*;import java.awt.image.BufferedImage;import javax.imageio.ImageIO;import java.io.File;import java.lang.reflect.Method;import java.util.*;
public class PaletteDebug{
 public static void main(String[] a)throws Exception{
  BufferedImage im=ImageIO.read(new File(a[0]));BoardDetector.Pixels p=new BoardDetector.Pixels(){public int width(){return im.getWidth();}public int height(){return im.getHeight();}public int argb(int x,int y){return im.getRGB(x,y);}};
  BoardDetector det=new BoardDetector(p);BoardDetector.Detection d=det.detect();Method m=BoardDetector.class.getDeclaredMethod("hueAt",double.class,double.class,boolean.class);m.setAccessible(true);
  double[] samples=new double[400];int n=0;
  for(int row=0;row<24;row++)for(int c=0;c<13;c++)if(d.board.valid(row,c)){double h=(double)m.invoke(det,d.board.x(row,c),d.board.y(row),false);if(h>=0)samples[n++]=h;}
  Arrays.sort(samples,0,n);System.out.println("board="+d.board.topY+" palette="+d.paletteSize+" counted="+d.count+" samples="+n);
  System.out.println("Hue groups:");int last=0;
  for(int i=1;i<n;i++)if(samples[i]-samples[i-1]>11){System.out.printf("%d..%d: %.1f..%.1f%n",last,i-1,samples[last],samples[i-1]);last=i;}
  System.out.printf("%d..%d: %.1f..%.1f%n",last,n-1,samples[last],samples[n-1]);
 }
}
