import pl.bubblebot.pro.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
public class BottomDebug{
 public static void main(String[]a)throws Exception{
 for(String x:a){BufferedImage b=ImageIO.read(new File(x));BoardDetector.Detection d=new BoardDetector(new BoardDetector.Pixels(){public int width(){return b.getWidth();} public int height(){return b.getHeight();}public int argb(int x,int y){return b.getRGB(x,y);}}).detect();
 System.out.println(x+" top="+d.board.topY);
 for(int r=12;r<Board.ROWS;r++){
 System.out.printf("  %d y=%.1f: ",r,d.board.y(r));for(int c=0;c<Board.COLS;c++){int v=d.board.cells[r][c];System.out.print(v==Board.INVALID?' ':v==Board.EMPTY?'.':"0123456789ABCDEFGHIJKLMNOPQRST".charAt(v));}System.out.println();}
 }
 }
}
