import pl.bubblebot.pro.Board;
import pl.bubblebot.pro.BoardDetector;
import pl.bubblebot.pro.ShotPlanner;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/** Runs using the JDK alone; no Android device or screen recording needed. */
public final class AdaptiveColorTest {
    private static void run(int colors) {
        BufferedImage image=new BufferedImage(864,1920,BufferedImage.TYPE_INT_RGB);
        Graphics2D g=image.createGraphics();
        g.setColor(new Color(25,4,71));g.fillRect(0,0,864,1920);
        Board board=new Board(300,0);
        for(int r=0;r<8;r++)for(int c=0;c<Board.COLS;c++){
            if(!board.valid(r,c))continue;
            int which=(r*7+c)%colors;
            float hue=(float)which/colors;
            g.setColor(Color.getHSBColor(hue,0.85f,0.98f));
            int x=(int)Math.round(board.x(r,c)),y=(int)Math.round(board.y(r));
            g.fillOval(x-28,y-28,56,56);
        }
        g.setColor(Color.getHSBColor(0f,0.85f,0.98f));
        g.fillOval(432-28,1724-28,56,56);
        g.setColor(Color.getHSBColor(1f/colors,0.85f,0.98f));
        g.fillOval(376-19,1756-19,38,38);
        g.dispose();
        BoardDetector.Detection d=new BoardDetector(new BoardDetector.Pixels(){
            public int width(){return image.getWidth();}
            public int height(){return image.getHeight();}
            public int argb(int x,int y){return image.getRGB(x,y);}
        }).detect();
        if(!d.playable() || d.paletteSize!=colors || d.current<0 || d.next<0){
            throw new AssertionError("Expected "+colors+" colours. Detected "+d.paletteSize+
                " playable="+d.playable()+" current="+d.current+" next="+d.next);
        }
        ShotPlanner.Shot shot=new ShotPlanner().choose(d.board,d.current);
        if(shot==null || !Double.isFinite(shot.targetX) || shot.targetX<0 || shot.targetX>864){
            throw new AssertionError("Invalid shot with "+colors+" colours");
        }
        System.out.println("PASS: "+colors+" dynamic colours, playable board, valid aim");
    }
    public static void main(String[] args) {
        run(3);run(6);run(7);run(8);run(10);
    }
}
