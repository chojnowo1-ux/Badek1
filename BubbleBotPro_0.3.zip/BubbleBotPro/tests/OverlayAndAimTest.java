import pl.bubblebot.pro.Board;
import pl.bubblebot.pro.BoardDetector;
import pl.bubblebot.pro.ShotPlanner;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/** Regression: controls cover the old footer pixels and aim/falling balls are
 * not fixed to the ceiling, so they MUST NOT become simulated obstacles. */
public final class OverlayAndAimTest {
    static void check(boolean p, String why){if(!p)throw new AssertionError(why);}
    static BoardDetector.Detection detect(BufferedImage img){
        return new BoardDetector(new BoardDetector.Pixels(){
            public int width(){return img.getWidth();}
            public int height(){return img.getHeight();}
            public int argb(int x,int y){return img.getRGB(x,y);}
        }).detect();
    }
    public static void main(String[] args){
        BufferedImage img=new BufferedImage(864,1920,BufferedImage.TYPE_INT_RGB);
        Graphics2D g=img.createGraphics();
        g.setColor(new Color(38,1,90));g.fillRect(0,0,864,1920);
        Board model=new Board(280,0);
        int[] colors={0xff276eea,0xff39d222,0xffee39c1,0xfff04c23};
        for(int r=0;r<7;r++)for(int c=0;c<Board.COLS;c++){
            if(!model.valid(r,c))continue;
            g.setColor(new Color(colors[(r+c)%4]));
            int x=(int)model.x(r,c),y=(int)model.y(r);
            g.fillOval(x-28,y-28,56,56);
        }
        // A brightly colored stray ball passing low on the screen.
        g.setColor(new Color(colors[0]));g.fillOval(412,1282,56,56);
        // Dot guidance at the exact center of a low virtual cell: diameter 12.
        g.setColor(new Color(colors[1]));g.fillOval(410,1402,12,12);
        // Diagnostic overlay completely blocks all four original right anchors.
        g.setColor(new Color(222,222,222));g.fillRect(535,1590,300,255);
        // Launcher bubbles, on their original pixel positions.
        g.setColor(new Color(colors[2]));g.fillOval(432-27,1724-27,54,54);
        g.setColor(new Color(colors[0]));g.fillOval(376-18,1756-18,36,36);
        g.dispose();
        BoardDetector.Detection d=detect(img);
        check(d.playable(),"Footer overlay must not stop actual game");
        check(d.count>=75,"Must detect full upper lattice: "+d.count);
        for(int r=11;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
            check(d.board.cells[r][c]<0,"False low bubble at row "+r+" col "+c);
        }
        ShotPlanner.Shot s=new ShotPlanner().choose(d.board,d.current);
        check(s!=null&&Double.isFinite(s.angleDegrees)&&Double.isFinite(s.targetX),"Valid shot");
        System.out.println("PASS overlay + detached bubble + tiny aim dots + valid aim");
    }
}
