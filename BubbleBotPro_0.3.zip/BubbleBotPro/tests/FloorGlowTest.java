import pl.bubblebot.pro.Board;
import pl.bubblebot.pro.BoardDetector;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/** Bottom red glow is not a grid of bubbles. Real shiny low bubbles remain visible. */
public final class FloorGlowTest {
  public static void main(String[] args){
    BufferedImage image=new BufferedImage(864,1920,BufferedImage.TYPE_INT_RGB);
    Graphics2D g=image.createGraphics();
    g.setColor(new Color(25,4,71));g.fillRect(0,0,864,1920);
    Board b=new Board(300,0);
    for(int row=0;row<8;row++)for(int c=0;c<13;c++){
      if(!b.valid(row,c))continue;
      g.setColor(Color.getHSBColor((row+c)%6/6f,.85f,.98f));
      int x=(int)b.x(row,c), y=(int)b.y(row);
      g.fillOval(x-28,y-28,56,56);
    }
    g.setColor(new Color(232,0,18));
    g.fillRect(600,1460,264,148);
    // One genuine cyan bubble within the red glow, complete with highlight.
    int bx=(int)b.x(21,10),by=1463;
    g.setColor(new Color(10,213,218));g.fillOval(bx-28,by-28,56,56);
    g.setColor(new Color(209,252,250));g.fillOval(bx-20,by-18,10,9);
    g.setColor(new Color(29,148,238));g.fillOval(404,1696,56,56);
    g.setColor(new Color(42,205,48));g.fillOval(357,1736,38,38);
    g.dispose();
    BoardDetector.Detection d=new BoardDetector(new BoardDetector.Pixels(){
       public int width(){return image.getWidth();}
       public int height(){return image.getHeight();}
       public int argb(int x,int y){return image.getRGB(x,y);}
    }).detect();
    int low=0;
    for(int row=20;row<Board.ROWS;row++)for(int c=0;c<Board.COLS;c++)
       if(d.board.cells[row][c]>=0)low++;
    if(low>1)throw new AssertionError("Red floor glow falsely detected as "+low+" balls");
    if(low==0)throw new AssertionError("Real highlighted low cyan bubble missed");
    System.out.println("PASS false floor-glow rejection and genuine low-bubble retention");
  }
}
