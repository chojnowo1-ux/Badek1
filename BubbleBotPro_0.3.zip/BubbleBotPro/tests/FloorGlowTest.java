import pl.bubblebot.pro.Board;
import pl.bubblebot.pro.BoardDetector;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/** The red floor warning must not be mistaken for a cluster of red bubbles. */
public final class FloorGlowTest{
 public static void main(String[]args){
  BufferedImage im=new BufferedImage(864,1920,BufferedImage.TYPE_INT_RGB);
  Graphics2D g=im.createGraphics();g.setColor(new Color(25,4,71));g.fillRect(0,0,864,1920);
  Board ref=new Board(308,1);
  for(int r=0;r<8;r++)for(int c=0;c<Board.COLS;c++)if(ref.valid(r,c)){
    g.setColor(Color.getHSBColor(((r+c)%6)/6f,.82f,.97f));
    g.fillOval((int)ref.x(r,c)-27,(int)ref.y(r)-27,54,54);
  }
  g.setColor(new Color(224,3,28));g.fillRect(60,1435,760,132);
  // Very low cyan bubble, shaded + highlight, not part of red background.
  int x=(int)ref.x(20,9),y=(int)ref.y(20);
  g.setColor(new Color(30,210,207));g.fillOval(x-28,y-28,56,56);
  g.setColor(new Color(211,246,242));g.fillOval(x-20,y-20,10,9);
  g.setColor(new Color(45,160,235));g.fillOval(404,1696,56,56);
  g.setColor(new Color(44,216,52));g.fillOval(358,1738,36,36);
  g.dispose();
  BoardDetector.Detection d=new BoardDetector(new BoardDetector.Pixels(){
   public int width(){return im.getWidth();}public int height(){return im.getHeight();}
   public int argb(int x,int y){return im.getRGB(x,y);}
  }).detect();
  int low=0;
  for(int r=17;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++)if(d.board.cells[r][c]>=0)low++;
  if(low>2 || low<1)throw new AssertionError("Expected one real low ball, not floor glow: "+low);
  System.out.println("PASS red-warning glow excluded, genuine bottom bubble kept");
 }
}
