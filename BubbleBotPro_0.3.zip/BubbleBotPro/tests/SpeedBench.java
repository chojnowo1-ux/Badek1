import pl.bubblebot.pro.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
public class SpeedBench{
 public static void main(String[] args)throws Exception{
   BufferedImage im=ImageIO.read(new File(args[0]));
   BoardDetector.Detection d=new BoardDetector(new BoardDetector.Pixels(){
     public int width(){return im.getWidth();}
     public int height(){return im.getHeight();}
     public int argb(int x,int y){return im.getRGB(x,y);}
   }).detect();
   for(int i=0;i<2;i++){ long t=System.nanoTime();
     ShotPlanner.Shot s=new ShotPlanner().choose(d.board,d.current);
     System.out.println("elapsed ms="+((System.nanoTime()-t)/1e6)+" shot="+s.angleDegrees+" removed="+s.removed);
   }
 }
}
