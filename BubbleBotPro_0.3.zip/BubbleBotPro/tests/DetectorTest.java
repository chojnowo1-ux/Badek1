import pl.bubblebot.pro.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;

public class DetectorTest {
  public static void main(String[] args) throws Exception {
    for(String file: args) {
      BufferedImage image=ImageIO.read(new File(file));
      BoardDetector.Pixels p=new BoardDetector.Pixels(){
        public int width(){return image.getWidth();}
        public int height(){return image.getHeight();}
        public int argb(int x,int y){return image.getRGB(x,y);}
      };
      BoardDetector.Detection d=new BoardDetector(p).detect();
      ShotPlanner.Shot s=new ShotPlanner().choose(d.board,d.current);
      System.out.printf("%s | y=%.1f phase=%d count=%d current=%d next=%d palette=%d quality=%.2f playable=%s\n",
        file,d.board.topY,d.board.phase,d.count,d.current,d.next,d.paletteSize,d.quality,d.playable());
      if(s!=null)System.out.printf("  angle=%.1f tap=(%.0f, %.0f), remove=%d drops=%d score=%.1f bounces=%d\n",s.angleDegrees,s.targetX,s.targetY,s.removed,s.dropped,s.score,s.bounceCount);
      for(int r=0;r<12;r++){
         System.out.printf("  %2d: ",r);
         for(int c=0;c<13;c++){
            int v=d.board.cells[r][c];System.out.print(v==Board.INVALID?' ':v==Board.EMPTY?'.':"0123456789ABCDEFGHIJKLMNOPQRST".charAt(v));
         }
         System.out.print("  X2:");
         for(int c=0;c<13;c++) if(d.board.bonusX2[r][c])System.out.print(" "+c);
         System.out.println();
      }
    }
  }
}
