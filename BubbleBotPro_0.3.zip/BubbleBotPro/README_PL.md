# BubbleBot Pro 0.7 — RETRO 0.3 FAST (po nagraniu z 2.11.2026)

Najważniejsze: **to powrót do prawdziwego silnika 0.3**, nie kolejna wersja
silnika 0.6. Z 0.3 zachowano szybkie zdjęcie/planowanie/gest, ciągłe
kolory adaptacyjne i dokładną symulację odbić. Nie ma dodatkowego oczekiwania
na dwie identyczne klatki ani wielkiego panelu statusu 0.6.

## Poprawki w porównaniu z 0.3

1. Pod panelem gry lub nakładką diagnostyczną wykrywanie planszy nie jest
   blokowane przez zakryte piksele po prawej stronie — dodatkowe punkty
   kontrolne są w niezasłoniętej lewej części paska gry.
2. Kulki odłączone od sufitu, ruchome kulki po zbiciu i plamki wskazujące
   kierunek strzału nie trafiają do planowania kolizji.
3. Analiza do 23 rzędów zamiast 21 — zwiększa szansę wykrycia prawdziwych
   kulek zbliżających się do dolnej linii.
4. Pozostaje punktowanie dużych zbić i odcinania grup z 0.3. Jedynie kiedy
   strzał nie zbija niczego, niskie i ryzykowne pozycje dostają ujemną wagę.
5. Wyczekiwanie po strzale: 710 ms standardowo, 820–930 ms przy odbiciach.
   Faktyczne tempo jest też ograniczone przez animacje gry i Androida.
6. App versionCode=7, versionName=0.7.0-retro03-fast.

## Testy

- `bash tests/run_tests.sh` — 3/6/7/8/10 dynamicznych kolorów, panel nad
  grą, fałszywe kulki, fałszywe kropki celownika oraz poprawny punkt celowania.
- Offline: 21 klatek filmu przesłanego 2 listopada — **21/21** rozpoznanych
  jako plansza w wersji 0.7, **10/21** przy starym detektorze 0.3
  zastosowanym do tego samego filmu z nakładką 0.6. Rozpoznawalność nie
  dowodzi celności strzału ani wyniku rundy.
- Testowane moduły czysto Java (JDK). **Nie zbudowano APK ani nie
  przetestowano nowej wersji na urządzeniu**. 500k punktów to cel, nie
  gwarancja.

## Najprostsza aktualizacja przez GitHub Actions (BEZ AndroidIDE)

Twój workflow `.github/workflows/build-apk-zip.yml` w repozytorium
`chojnowo1-ux/Badek1` szuka archiwum **BubbleBotPro_0.3.zip**. To tylko
nazwa pliku używana w workflow — zawartość nowej paczki to już 0.7.

1. Pobierz `BubbleBotPro_07_RETRO03_FAST_20261102.zip` z ChatGPT.
2. W menedżerze plików zmień nazwę pobranego archiwum na
   `BubbleBotPro_0.3.zip` (zastępując starą kopię o tej nazwie).
3. Wejdź na `https://github.com/chojnowo1-ux/Badek1/upload/main`,
   wgraj ten ZIP i zatwierdź `Commit changes`, podmieniając plik w repo.
4. Otwórz `https://github.com/chojnowo1-ux/Badek1/actions`.
   Wybierz pomyślną kompilację `Build BubbleBot Pro 0.3 APK` (nazwa workflow
   może pozostać stara), pobierz jej `Artifacts`, rozpakuj i instaluj APK.
5. Jeśli podpis debug jest inny niż w obecnej instalacji, Android może
   odmówić aktualizacji; wtedy przed reinstalacją zachowaj dane, a potem
   ponownie skonfiguruj dostępność. Nie wyłączaj zabezpieczeń bez potrzeby.

Uwaga: dostępność pozwala aplikacji oglądać ekran i dotykać poza grą.
Przyznawaj te uprawnienia wyłącznie sprawdzonemu plikowi.
Automatyzacja może naruszać zasady gry/turnieju.
