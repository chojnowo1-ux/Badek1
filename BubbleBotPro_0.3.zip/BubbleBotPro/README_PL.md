# BubbleBot Pro v0.4 — Tryb przetrwania (survival-first)

AKTUALIZACJA v0.4: Priorytetem jest utrzymanie kulek powyżej fioletowej linii przegranej, nie maksymalizacja punktów w pojedynczym strzale.

Zmiany:
- Rozpoznawanie 24 rzedow zamiast 21 — kontrola najnizszych kulek.
- Prognoza zagrozenia przed/po strzale i preferowanie odcinania dolnych grup od sufitu.
- Wirtualne usuwanie spadajacych kulek podczas symulacji (wczesniej pozostawaly jako przeszkody).
- Niska ocena strzalow dokladajacych kulki blisko linii przegranej.
- Gdy nie ma natychmiastowego zbicia, bot patrzy takze na kolejna widoczna kulke.
- Odrzucanie czerwonej poswiaty dolnej strefy udajacej kulki.
- Dwie zgodne klatki przed kazdym strzalem, aby nie strzelac w trakcie animacji.
- Dynamiczne wykrywanie kolorow nadal bez limitu szesciu barw.

WAZNE: Nazwa ZIP `BubbleBotPro_0.3.zip` jest zachowana tylko dla kompatybilnosci z istniejacym w repozytorium `build-apk-zip.yml`. Po kompilacji aplikacja ma wersje 0.4.0.

Kompilacja: wgraj NOWY ZIP `BubbleBotPro_0.3.zip` do korzenia repozytorium, zastap poprzedni plik o tej samej nazwie; obecny workflow Build BubbleBot Pro 0.3 APK nadal bedzie go widzial. W Actions pobierz nowy artefakt z NAJNOWSZEGO przebiegu.

TESTY lokalne (bez emulatora): `bash tests/run_tests.sh`. Testy sprawdzaja 3/6/7/8/10 barw, odrzucanie czerwonej poswiaty, decyzje w strefie zagrozenia. Dzialanie w samej grze wymaga sprawdzenia na urzadzeniu — progi sa dopasowane do przeslanych zrzutow 864x1920 (przeskalowanych).

---

# BubbleBot Pro 0.3 — adaptacyjne kolory, szybsze strzały, precyzyjne odbicia

## Co zmieniono w tej wersji

- **Kolory bez ręcznej listy:** detektor buduje paletę barw na nowo z widocznych kulek i wyrzutni. Na dostarczonym nowym zrzucie rozpoznaje 6 kolorów, na wcześniejszym 3. W testach syntetycznych rozpoznał również 7, 8 i 10 kolorów. Bardzo ciemne, białe lub słabo nasycone nowe barwy mogą nadal wymagać dostrojenia.
- **Szybciej:** standardowe opóźnienie po strzale zmniejszono z 1150 ms do 730 ms (850–970 ms przy odbiciach). Przy niezmienionej planszy ponowna kontrola następuje po 350 ms zamiast 1650 ms. Ostateczne tempo zależy od gry i systemowego limitu zrzutów ekranu Androida.
- **Precyzja:** usunięto kwantowanie trajektorii co 4,1 px; symulator liczy dokładne przecięcia promienia z kulkami, odbicia od ścian i sprawdza kąty z dokładnością do 0,15 stopnia. Preferuje kąty odporne na niewielkie przesunięcia celowania (±0,3°).
- **Kalibracja:** poprawiono poziomy środek wyrzutni na 432/864 szerokości ekranu, zgodnie z ostatnim zrzutem (wcześniej 416/864). Przesunięto też odczyt koloru następnej kulki.
- **Ochrona:** bot nie ponawia strzału w tym samym stanie planszy i wstrzymuje działanie, jeżeli nie rozpoznaje gry; działa bez połączenia z Internetem.

## GITHUB ACTIONS — budowanie APK bez AndroidIDE (zalecane)

Nie uzywamy AndroidIDE. Dla tej wersji aktualizujemy pliki z folderu `BubbleBotPro` w repozytorium GitHub (tak zeby `app`, `.github`, `settings.gradle` byly w katalogu glownym repo). Nastepnie: GitHub -> Actions -> Build BubbleBot Pro APK -> Run workflow. Po zielonym zakonczonym przebiegu pobierz artifact `BubbleBotPro-v0.3-APK`, rozpakuj go i zainstaluj `app-debug.apk`.

**Poprawka workflow:** `android-actions/setup-android@v4` oraz `packages: ''` zamiast starszego `setup-android@v3`, ktory w niektorych przebiegach probowal instalowac wycofany pakiet Android SDK `tools`.

---

## Pliki i instalacja na telefonie

**To źródła projektu, nie gotowe APK.** W tym środowisku nie było Android SDK, więc kompilacja Android i test działania na telefonie nie są jeszcze potwierdzone. Testy czysto Javowe przechodzą.

1. Wgraj zawartosc folderu `BubbleBotPro` do repozytorium GitHub.
2. Uruchom `Actions > Build BubbleBot Pro APK > Run workflow`.
3. Pobierz artifact `BubbleBotPro-v0.3-APK` i wypakuj `app-debug.apk`.
4. Jeśli Android nie pozwala zaktualizować dotychczasowej wersji, przyczyną może być inny klucz podpisu debug. Zachowaj kopię starej instalacji; w razie potrzeby odinstaluj starą wersję przed instalacją nowej i ponownie skonfiguruj dostępność. Nie omijaj ostrzeżeń bezpieczeństwa bez sprawdzenia pochodzenia aplikacji.

Testy na komputerze/JDK (bez Android SDK): `sh tests/run_tests.sh`.

**Uwaga:** to nie jest gwarancja wyższych wyników — symulowane zasady punktacji oraz fizyka gry wymagają jeszcze potwierdzenia w rozgrywce. Korzystanie z automatyzacji może naruszać zasady gry lub turnieju.

---

## Historia i poprzednia instrukcja (wersja 0.1.2)

# BubbleBot Pro – prototyp 0.1 na Androida

## Co jest zrobione

Aplikacja na Androida 11+ (w tym Androida 16), napisana w Java, bez serwera i roota:

- **Tylko AUTO**: po uruchomieniu wykonuje serię zdjęcie ekranu → rozpoznanie → symulacja 201 kątów z odbiciami → punktacja → wykonanie dotknięcia → ponowna analiza.
- Rozpoznaje kolory: niebieski, zielony, różowy i czerwony oraz aktualną/następną kulkę.
- Buduje siatkę heksagonalną, symuluje połączenia, usunięcia i opadanie kulek.
- Uwzględnia potencjalne strefy 50 / 100 / 250 i wykrywa oznaczenie bonusu x2 (szacowana punktacja).
- Wznawia kolejny mecz tylko po rozpoznaniu konkretnego ekranu wyników ze słowem GRAJ, udokumentowanego na nagraniu.
- Przycisk AUTO/STOP wyświetla się jako nakładka usługi dostępności; w aplikacji są także START i STOP.
- Nie wymaga konta ani Internetu; nie zbiera zawartości elementów dostępności, nie przechowuje i nie wysyła zrzutów ekranu.

## Co przetestowano

Moduły czysto-Javowe skompilowano lokalnie i uruchomiono na dwóch zrzutach oraz 19 klatkach pobranych co 2 sekundy z przekazanego wideo. Wykrywanie wybranych klatek:

- 00:02 – 65 kulek, niebieska w wyrzutni, zielona następna.
- 00:16 – 50 kulek, różowa w wyrzutni i różowa następna; osobno rozpoznano kulkę z x2.
- 00:14 – rozpoznany ekran końca gry z przyciskiem GRAJ.
- Panel powiadomień i ekran przejściowy nie zostały zakwalifikowane jako działająca plansza.

**Ważne:** nie ma testu kompilacji Android SDK ani testu na rzeczywistym Androidzie. Trafność celowania i wynik punktowy nie zostały zweryfikowane przez rozegranie rundy. Symulator przyjmuje szacunkowe promienie, szybkość i zasady punktacji; może wymagać kalibracji po pierwszych testach. To kod źródłowy, nie skompilowane APK.

## Kompilacja APK bez komputera

Opcja 1: AndroidIDE (nie jest już rozwijane; działanie na Androidzie 16 nie jest potwierdzone) lub inne IDE na Androida obsługujące projekty Gradle. Otwórz folder projektu i wybierz `assembleDebug`. Może być potrzebna konfiguracja SDK/Gradle oraz zaakceptowanie dostępu do plików.

Opcja 2: GitHub Actions – dołączono `.github/workflows/build-apk.yml` wykorzystujący chmurową maszynę budującą Androida. Wgraj rozpakowany projekt do własnego repozytorium GitHub, uruchom workflow `Build BubbleBot Pro APK` (lub wypchnij commit na `main`). W sekcji Artifacts będzie `BubbleBotPro-debug-APK` zawierający `app-debug.apk`. *Workflow jest przygotowany, ale nie był uruchomiony.*

Alternatywnie Android Studio na komputerze: otwórz projekt, użyj Build > Build APK(s) (wymaga Android SDK 35, Gradle 8.9, Java 17).

## Instalacja i uruchomienie (po zbudowaniu APK)

1. Zainstaluj `app-debug.apk` na swoim telefonie; Android może poprosić o zgodę na instalację z danego źródła.
2. Uruchom BubbleBot Pro. Wybierz „Włącz dostępność BubbleBot Pro”, następnie w systemowych ustawieniach włącz tę usługę.
3. Jeśli Android blokuje przełącznik z powodu ograniczeń instalacji z zewnętrznego źródła, znajdź BubbleBot Pro → informacje o aplikacji → menu z trzema kropkami → „Zezwalaj na ograniczone ustawienia” (nazwa zależy od producenta i wersji Androida). Nadawaj to uprawnienie wyłącznie aplikacji, której kod rozumiesz i której ufasz.
4. Otwórz Bubble Shooter Pro, upewnij się, że wyświetla się plansza. Naciśnij przycisk `▶ AUTO` w nakładce.
5. `■ STOP` zatrzymuje kolejne zrzuty i dotknięcia. Należy pozostawić grę na wierzchu, z włączonym ekranem.

## Wymagania i ograniczenia

- Android API 30+; aplikacja działa w trybie pionowym i zakłada proporcje ekranu i pozycje obiektów z przesłanego filmu 864×1920, skalowane na rozdzielczość urządzenia.
- Nie korzysta z OCR, AccessibilityService przechwytuje ekran za pośrednictwem `takeScreenshot` i dotyka przez `dispatchGesture`.
- Jeśli Android zablokuje zrzuty ekranu (np. chronione okno), bot nie będzie działać; nie próbuje omijać zabezpieczeń.
- Nieznane layouty gry, reklamy i interfejsy nie powinny być automatycznie obsługiwane. Najpierw przetestuj w zwykłej rozgrywce, zanim uznasz algorytm za gotowy na turniej.
- Automatyzacja może być niezgodna z zasadami organizatora lub gry.

## Struktura kodu

- `BoardDetector.java` – kolory, pozycje, siatka, bonus x2.
- `ShotPlanner.java` – symulacja strzałów z odbiciami i heurystyka punktowa.
- `MenuDetector.java` – kontrolowany restart na udokumentowanym ekranie.
- `BotAccessibilityService.java` – zdjęcia ekranu, gesty i nakładka AUTO/STOP.
- `MainActivity.java` – ekran konfiguracji.
- `tests` – testy obrazów uruchamiane JDK bez Androida.

Przykładowy test desktop (gdy zrzuty są dostępne):

```sh
mkdir -p tests/bin
javac -d tests/bin app/src/main/java/pl/bubblebot/pro/{Board,BoardDetector,ShotPlanner,MenuDetector}.java tests/DetectorTest.java tests/MenuTest.java
java -cp tests/bin DetectorTest /sciezka/do/bubble_35.png
```

## Poprawka 0.1.1

W pliku `build.gradle` dopisano wersję Android Gradle Plugin (`8.7.3`) wymaganą do pobrania w trakcie kompilacji z użyciem Gradle 8.9. Pakiet nadal zawiera kod źródłowy, nie APK.

## Poprawka 0.1.2 — błąd AndroidIDE `./gradlew` nie istnieje

Wersja 0.1.1 omyłkowo nie zawierała pliku `gradlew`, dlatego AndroidIDE kończył budowanie kodem 127.

Wersja 0.1.2 dodaje skrypt `gradlew` oraz `gradle/wrapper/gradle-wrapper.properties`.
Ze względu na brak możliwości dołączenia binarnego JAR w środowisku tworzenia paczki, przy
pierwszym uruchomieniu **skrypt pobierze oficjalny plik Gradle Wrapper JAR 8.9** z repozytorium
Gradle i **sprawdzi jego SHA-256** według https://gradle.org/release-checksums/ .
Następnie oficjalny Wrapper pobierze Gradle 8.9 (ok. 130 MB) i sprawdzi sumę SHA-256 dystrybucji.
Do pierwszej kompilacji niezbędny jest internet oraz dostęp do `raw.githubusercontent.com` i
`services.gradle.org`, JDK 17, Android SDK 35 i poprawne narzędzia AndroidIDE.

**Uruchomienie na telefonie:** zamknij wcześniejszy projekt w AndroidIDE, usuń poprzednią
rozpakowaną wersję lub rozpakuj nową w innym miejscu, wybierz `Open existing project` i wskaż
`BubbleBotPro` — folder, który bezpośrednio zawiera `gradlew`, `settings.gradle` i `app`.
Dotknij Run/Build. Nie otwieraj folderu `app` jako głównego projektu.

**Ograniczenie:** projekt zaktualizowano w zakresie brakującego uruchamiacza Gradle, ale
kompilacja na Androidzie 16 nie została zweryfikowana. Ten ZIP nadal nie jest plikiem APK.
Alternatywnie workflow GitHub Actions dołączony do projektu używa `gradle` bezpośrednio i
nie wymaga tego skryptu.
