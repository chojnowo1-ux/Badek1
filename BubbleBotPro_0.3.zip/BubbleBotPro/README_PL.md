# BubbleBot Pro 0.5 — precyzja siatki, punkty i bezpieczne strzały

## Co zmieniono względem 0.4

- Bazą jest szybszy, bardziej skuteczny silnik 0.3. Wycofano nadmierne, globalne karanie za niskie kulki, niepewne planowanie dwóch strzałów i dodatkowe oczekiwanie na drugi zrzut ekranu.
- Poprawiono prawdziwą przyczynę wielu niecelnych decyzji: rozstaw pionowy rzędów z 56.5 do 57.6 jednostki odniesienia (864x1920). Przy 20 rzędach daje to ~22 jednostki różnicy. Ulepszono też dopasowanie początku siatki przez wykrywanie krawędzi kulek.
- Zachowano dynamiczne rozpoznawanie kolorów (bez zamkniętej listy barw). Odfiltrowano odosobnione artefakty odcienia, czerwone podświetlenie przy dolnej linii i błędne rozdzielenie czerwieni na 0/360 stopni.
- Premia za realnie zdjęte kulki wiszące nisko; kara za strzał bez zbicia, który dokłada kulkę blisko przegranej. Premiowanie dużych zbić i odciętych grup pozostało priorytetem.
- Rozpoznawanie do 24 rzędów, strzały i odbicia oparte na silniku 0.3.

## Jak zbudować na GitHub Actions

Aktualny workflow repozytorium `chojnowo1-ux/Badek1` korzysta z ZIP-a umieszczonego w głównym katalogu repozytorium o nazwie `BubbleBotPro_0.3.zip`.

1. Pobierz ten archiwum z rozmowy. Jeśli nosi dłuższą unikalną nazwę, zmień na telefonie nazwę na `BubbleBotPro_0.3.zip` (nie rozpakowuj).
2. W GitHub → repozytorium Badek1 → Upload files prześlij plik do głównego katalogu, zastępując poprzedni ZIP, i zatwierdź Commit changes do `main`.
3. GitHub Actions: kompilacja `Build BubbleBot Pro 0.3 APK` powinna uruchomić się po zatwierdzeniu. Nazwa workflow/artefaktu może pozostać 0.3; w środku aplikacja będzie oznaczona jako 0.5.
4. Po zielonym wyniku pobierz artefakt APK, rozpakuj pobrany artefakt i zainstaluj `app-debug.apk`.

**Uwaga:** wersje testowe budowane na różnych runnerach GitHub mogą mieć różne klucze podpisu APK. Jeśli aktualizacja nie przechodzi, może być konieczne odinstalowanie poprzedniej wersji i ponowne nadanie uprawnień dostępności. Zanim przyznasz dostępność aplikacji instalowanej spoza sklepu, zweryfikuj źródło i uprawnienia.

## Wyniki testów

- 3/6/7/8/10 kolorów: PASS (syntetyczne plansze).
- Zapełniona plansza z 250 kulkami: wykryto 248, PASS.
- Czerwona poświata ostrzegawcza i rzeczywista niska kulka: PASS.
- Ostatni ekran przesłany przez użytkownika: 0.4 wykrywała około 160 kulek, nowy model wykrywa 207, 6 barw (pomiar statyczny, bez filmu i bez testu na urządzeniu).
- Próba celowania w statyczny zrzut ekranu: uruchomiona lokalnie na JDK; nie zweryfikowano faktycznego efektu w grze.

Nie twierdzimy, że nowa wersja już zdobywa więcej punktów — to trzeba potwierdzić w grze na prawdziwym telefonie.
