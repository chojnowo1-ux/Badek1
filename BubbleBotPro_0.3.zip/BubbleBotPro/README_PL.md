# BubbleBot Pro 0.5 — Survival

**Cel testowy: 500 000 pkt. To ambitny cel, nie sprawdzony wynik.**

Nowa wersja została opracowana na podstawie przekazanego nagrania z 2026-11-02. W nagraniu przy ~86 450 pkt zagrożone kulki były po prawej przy dolnej linii, podczas gdy poprzedni bot celował w inne obszary. Strategia w tej wersji karze budowanie pod dolną linią i premiuje usuwanie dolnych, niebezpiecznych grup.

## Zmiany
- Rzutowanie na heksagonalną siatkę 13×24 z klatek gry 864×1920 (wewnętrznie do 830×1848), zamiast śledzenia spadających kulek i kropek celownika.
- Klasyfikacja 6 kolorów na podstawie 5 próbek każdej kulki, test na klatce z blisko 185 kulkami.
- 301 symulowanych kątów z odbiciami od bocznych ścian, pomiar kolizji oraz prawidłowy snap do sąsiedniej wolnej komórki.
- Odtwarzanie łączenia minimum 3 jednakowych kulek, a następnie odcinanie grup niepołączonych z sufitem.
- Osobna, silnie nieliniowa kara za ryzyko przy dolnej linii; większa premia za ratowanie najniższych grupek.
- Inteligentna zamiana bieżącej kulki z następną, tylko jeśli symulacja wykazuje większą korzyść. Po pierwszej próbie bot sprawdza, czy gra obsługuje zmianę koloru; przy braku zmiany wyłącza tę funkcję, bez ponawiania prób.
- Stabilizacja obrazu przed strzałem i potwierdzanie jego skutku; nie wysyła kolejnych dotknięć na ślepo.
- Działanie w pełni lokalne na Androidzie bez OCR, bez roota, bez komputera.

## Budowanie za pomocą GitHub Actions na telefonie
1. Otwórz własne repozytorium `chojnowo1-ux/Badek1`.
2. Wgraj **BubbleBotPro_0.5.zip** do katalogu głównego, bez rozpakowywania.
3. W repozytorium utwórz plik `.github/workflows/build-bubblebot-05.yml` z treścią oddzielnie dołączonego pliku `build-bubblebot-05.yml` (zapisz dokładnie w tym katalogu).
4. Przejdź do **Actions** → **Build BubbleBot Pro 0.5 APK** → **Run workflow**, a następnie pobierz `BubbleBotPro-0.5-APK` → `app-debug.apk`.
5. Jeśli poprzednia wersja jest zainstalowana i system odmawia aktualizacji, odinstaluj ją (może być podpisana innym kluczem debug). Zainstaluj APK na Androidzie 11+, otwórz, włącz usługę dostępności i przy uruchomionej grze kliknij **▶ AUTO 500K**.

**Opcja kompatybilna z Twoim starym workflow:** jeśli workflow nadal rozpakowuje `BubbleBotPro_0.3.zip` do `project/BubbleBotPro`, możesz zamiast dodawać nowy workflow wgrać zawartość nowego ZIP pod starą nazwą. Wtedy stary workflow zbuduje wersję 0.5.

## Testy
`bash BubbleBotPro/tests/run_tests.sh` z repozytorium rozpakowanego ZIP. Używa JDK 17. Testy: dopasowanie trójek, odbicie/kolizja przy krawędzi, brak strzałów na pustej planszy, scenariusz klatki z 86 tys. pkt oraz stwierdzenie, że zamiana z niebieskiej na żółtą daje zbicie 4 i odcięcie 7 kulek.

## Ograniczenia
- Przetestowano symulator w Javie (bez Android SDK) oraz próbki kolorów w Pythonie na jednym zatrzymanym ujęciu. **Nie skompilowano lokalnie APK i nie zweryfikowano skuteczności w realnej grze.**
- Bazowa geometria odpowiada przesłanemu nagraniu w pionie; inne motywy/rozdzielczości/interfejsy mogą wymagać zmian w `BoardState`/`GameVision`.
- Game over / restart nie jest w tej wersji automatycznie klikany, bo brak zweryfikowanego układu przycisku w przesłanym nagraniu. Bot przestaje oddawać strzały, jeśli plansza przestaje być rozpoznawana.
- Gra może blokować usługę dostępności lub zrzuty, a organizator turnieju może zabraniać automatyzacji.
- Dzięki stopowi po braku reakcji bota można łatwo sprawdzić, czy kliknięcia są akceptowane.
