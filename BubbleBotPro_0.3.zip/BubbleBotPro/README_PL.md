# BubbleBot Pro 0.6 — poprawki z nagrania (2 listopada 2026)

Ta wersja opiera się na działającej rodzinie 0.5 z komunikatem „AUTO 500K”.

**Poprawki:**
- Autokalibracja położenia siatki (y=248–288 w układzie 830×1848).
- Rozpoznawanie dwóch wariantów przesunięcia rzędów po dodaniu kolejnych kulek od góry.
- Szybsze planowanie: symulacja oceniana tylko raz na unikalne pole docelowe.
- Gdy kolejna kulka ma ten sam kolor, większa korzyść z ustawienia pary.
- Rezygnacja z prób zamiany kolorów, która na nagraniu nie działała.
- Status bota podaje faktyczny czas planowania w milisekundach.
- Filtr wielkości obiektu odrzuca małe kropki linii celowania.
- Usuwa z modelu piłki niepołączone z sufitem (spadające podczas animacji).

**Uwaga:** skan kolorów w kodzie rozpoznaje obecne w grze sześć barw. Nowszych, nieznanych barw nie zweryfikowano. Wynik 500 tys. nie jest gwarantowany; konieczne są próby na telefonie.

## Kompilacja
W repozytorium z workflow `build-bubblebot-05.yml` nowy ZIP należy przesłać pod nazwą `BubbleBotPro_0.5.zip` do głównego katalogu. GitHub Actions zbuduje `app-debug.apk`. Aplikacja korzysta z usługi dostępności; przed przyznaniem jej uprawnień zweryfikuj źródło aplikacji, uprawnienia i status Play Protect.

## Testy
`bash BubbleBotPro/tests/run_tests.sh`

