package pl.bubblebot.pro;

import java.util.Arrays;
import java.util.ArrayDeque;

/**
 * Local, frame-adaptive colour recognition. No fixed list of red/green/blue/etc.
 * A bubble's hue is estimated from several interior pixels, then the palette
 * is discovered anew from the actual board and the two launcher bubbles.
 * Palette IDs are meaningful only within one detected frame.
 */
public final class BoardDetector {
    public interface Pixels { int width(); int height(); int argb(int x, int y); }
    public static final class Detection {
        public final Board board;
        public final int current, next;
        public final int count, paletteSize;
        public final double quality;
        Detection(Board board, int current, int next, int paletteSize, double quality) {
            this.board=board; this.current=current; this.next=next;
            this.count=board.occupied; this.paletteSize=paletteSize; this.quality=quality;
        }
        public boolean playable() {
            return count>=12 && count<=290 && current>=0 && paletteSize>0 && quality>=0.25;
        }
    }
    private static final int[][] BOARD_OFFSETS = {
        {0,7},{10,6},{-10,6},{12,0},{-12,0},{0,-10},{5,-9},{-5,-9},{0,0}
    };
    private static final int[][] SMALL_OFFSETS = {
        {0,0},{-5,1},{5,1},{0,5},{0,-5}
    };
    // Adjacent swatches in one colour usually vary < 8 degrees.
    // A gap above this value marks a possible new colour, even if the hue
    // has never been seen before (e.g. cyan, orange or a future seventh hue).
    private static final double GROUP_GAP_DEGREES=11.0;
    private static final int MAX_PALETTE=24; // reject highly fragmented/non-game imagery
    private final Pixels frame;
    private final double sx,sy;
    public BoardDetector(Pixels frame) {
        this.frame=frame;
        this.sx=frame.width()/864.0;
        this.sy=frame.height()/1920.0;
    }
    private int at(double x,double y) {
        int px=(int)Math.round(x*sx),py=(int)Math.round(y*sy);
        if(px<0||py<0||px>=frame.width()||py>=frame.height())return 0xff000000;
        return frame.argb(px,py);
    }
    /** Returns circular hue [0,360) or -1 if too dark or near-white. */
    private static double hue(int argb) {
        int r=(argb>>>16)&255, g=(argb>>>8)&255, b=argb&255;
        int max=Math.max(r,Math.max(g,b)), min=Math.min(r,Math.min(g,b));
        int d=max-min;
        // A purple playfield is typically max=75..120, whereas a real
        // bubble has bright saturated interior pixels. White labels are ignored.
        if(max<155 || d<38 || d*100<max*29)return -1;
        double h;
        if(max==r)h=60.0*(g-b)/d;
        else if(max==g)h=120.0+60.0*(b-r)/d;
        else h=240.0+60.0*(r-g)/d;
        if(h<0)h+=360;
        return h;
    }
    private double hueAt(double x,double y,boolean small){
        int[][] offsets=small?SMALL_OFFSETS:BOARD_OFFSETS;
        double cs=0,ss=0;
        int n=0;
        for(int[] of:offsets){
            double h=hue(at(x+of[0],y+of[1]));
            if(h<0)continue;
            cs+=Math.cos(Math.toRadians(h));
            ss+=Math.sin(Math.toRadians(h));
            n++;
        }
        if(n<(small?3:5))return -1;
        // If several different colours leak into a sample, don't invent one.
        if(Math.hypot(cs,ss)/n<0.955)return -1;
        double h=Math.toDegrees(Math.atan2(ss,cs));
        return h<0?h+360:h;
    }
    private boolean hasBonusLabel(double x,double y) {
        int white=0;
        for(int yy=9;yy<=21;yy+=2)for(int xx=-22;xx<=22;xx+=2) {
            int argb=at(x+xx,y+yy);
            int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;
            if(r>165 && g>160 && b>135)white++;
        }
        return white>=7;
    }
    private static double circularDistance(double x,double y){
        double diff=Math.abs(x-y);return Math.min(diff,360-diff);
    }
    private static final class Palette {
        final double[] centers;
        Palette(double[] centers){this.centers=centers;}
        int nearest(double hue){
            if(hue<0)return Board.EMPTY;
            int id=Board.EMPTY;
            double nearest=16.0;
            for(int i=0;i<centers.length;i++){
                double d=circularDistance(hue,centers[i]);
                if(d<nearest){nearest=d;id=i;}
            }
            return id;
        }
    }
    private static Palette makePalette(double[][] swatches,double current,double next){
        double[] samples=new double[Board.ROWS*Board.COLS+2];
        int n=0;
        for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
            if(swatches[r][c]>=0)samples[n++]=swatches[r][c];
        }
        if(current>=0)samples[n++]=current;
        if(next>=0)samples[n++]=next;
        if(n==0)return new Palette(new double[0]);
        Arrays.sort(samples,0,n);
        // Partition observed hues at natural gaps. No named-colour thresholds.
        int[] starts=new int[n];int count=0;
        starts[count++]=0;
        for(int i=1;i<n;i++){
            if(samples[i]-samples[i-1]>GROUP_GAP_DEGREES)starts[count++]=i;
        }
        if(count>MAX_PALETTE)return new Palette(new double[0]);
        double[] centers=new double[count];
        for(int g=0;g<count;g++){
            int start=starts[g],end=g+1<count?starts[g+1]:n;
            double cx=0,cy=0;
            for(int i=start;i<end;i++){
                cx+=Math.cos(Math.toRadians(samples[i]));
                cy+=Math.sin(Math.toRadians(samples[i]));
            }
            double h=Math.toDegrees(Math.atan2(cy,cx));
            centers[g]=h<0?h+360:h;
        }
        // Red spans the 0/360 boundary. Merge both extremes if they belong
        // to one hue rather than letting red accidentally become two colours.
        if(count>1 && samples[0]+360-samples[n-1]<=GROUP_GAP_DEGREES){
            int last=count-1;
            int firstEnd=starts[1],lastStart=starts[last];
            double cx=0,cy=0;
            for(int i=0;i<firstEnd;i++){
                cx+=Math.cos(Math.toRadians(samples[i]));
                cy+=Math.sin(Math.toRadians(samples[i]));
            }
            for(int i=lastStart;i<n;i++){
                cx+=Math.cos(Math.toRadians(samples[i]));
                cy+=Math.sin(Math.toRadians(samples[i]));
            }
            double h=Math.toDegrees(Math.atan2(cy,cx));
            centers[0]=h<0?h+360:h;
            centers=Arrays.copyOf(centers,count-1);
        }
        return new Palette(centers);
    }
    private boolean recognisableGameFooter(){
        // The current game's lower dark-purple strip is stable across
        // empty and nearly full boards. Don't use a *playfield* pixel for
        // this test: a full board can cover any such pixel with a ball.
        int matches=0;
        // Right-hand status/control overlays can cover all the original anchors.
        // Also check the unobstructed left footer, rather than rejecting the
        // real game and waiting several seconds for a false negative.
        for(int[] xy:new int[][]{{600,1650},{740,1650},{600,1755},{740,1770},
                                 {185,1650},{275,1650},{260,1780},{310,1810}}){
            int col=at(xy[0],xy[1]);
            int r=(col>>>16)&255,g=(col>>>8)&255,b=col&255;
            if(b>r*1.35 && b>g*2.1 && b>48 && b<160 && g<45)matches++;
        }
        return matches>=3;
    }
    /** A stationary game bubble is always ceiling-connected on the hex grid.
     * Ignore falling particles, laser/aim dots and flash effects while choosing
     * a target; never infer a dangerous low stack from detached screen effects.
     */
    private static void removeUnattached(Board board){
        boolean[][] attached=new boolean[Board.ROWS][Board.COLS];
        ArrayDeque<int[]> queue=new ArrayDeque<>();
        for(int c=0;c<Board.COLS;c++)if(board.cells[0][c]>=0){
            attached[0][c]=true;queue.add(new int[]{0,c});
        }
        int[][] neighbors=new int[6][2];
        while(!queue.isEmpty()){
            int[] cell=queue.removeFirst();
            int count=board.neighbours(cell[0],cell[1],neighbors);
            for(int i=0;i<count;i++){
                int r=neighbors[i][0],c=neighbors[i][1];
                if(!attached[r][c] && board.cells[r][c]>=0){
                    attached[r][c]=true;queue.add(new int[]{r,c});
                }
            }
        }
        for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
            if(board.cells[r][c]>=0 && !attached[r][c]){
                board.cells[r][c]=Board.EMPTY;
                board.bonusX2[r][c]=false;
                board.occupied--;
            }
        }
    }

    public Detection detect(){
        if(frame.width()<400 || frame.height()<750)
            return new Detection(new Board(285,0),-1,-1,0,0);
        // Geometry fit is based on the presence of a saturated circular
        // swatch, not on which colour that swatch happens to be.
        double bestScore=Double.NEGATIVE_INFINITY, top=280;
        int phase=0;
        for(int p=0;p<=1;p++)for(int yi=274;yi<=304;yi+=2){
            Board candidate=new Board(yi,p);
            double score=0;int seen=0;
            for(int r=0;r<10;r++)for(int c=0;c<Board.COLS;c++){
                if(!candidate.valid(r,c))continue;
                if(hueAt(candidate.x(r,c),candidate.y(r),false)>=0){
                    score+=(r<5?2.1:1.0);seen++;
                }
            }
            if(seen>0&&score>bestScore){bestScore=score;top=yi;phase=p;}
        }
        Board board=new Board(top,phase);
        double[][] swatches=new double[Board.ROWS][Board.COLS];
        for(int r=0;r<Board.ROWS;r++){
            Arrays.fill(swatches[r],-1);
            for(int c=0;c<Board.COLS;c++){
                if(board.valid(r,c)&&board.y(r)<=1538)
                    swatches[r][c]=hueAt(board.x(r,c),board.y(r),false);
            }
        }
        double currentHue=hueAt(432,1724,false);
        double nextHue=hueAt(376,1756,true);
        Palette palette=makePalette(swatches,currentHue,nextHue);
        for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
            if(!board.valid(r,c))continue;
            int id=palette.nearest(swatches[r][c]);
            board.cells[r][c]=id;
            if(id>=0){
                board.occupied++;
                // May appear on any ball colour (including cyan and blue).
                board.bonusX2[r][c]=hasBonusLabel(board.x(r,c),board.y(r));
            }
        }
        // Moving balls / aiming-guide dots are not fixed to the ceiling. They
        // must NOT participate in collision simulation or danger assessment.
        // Preserve the exact v0.3 colour palette and aiming algorithm.
        removeUnattached(board);
        double quality=recognisableGameFooter() ? Math.min(1.0,board.occupied/26.0):0;
        return new Detection(board,palette.nearest(currentHue),palette.nearest(nextHue),palette.centers.length,quality);
    }
}
