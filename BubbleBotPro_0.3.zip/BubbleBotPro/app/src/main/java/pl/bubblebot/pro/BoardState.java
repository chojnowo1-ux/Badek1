package pl.bubblebot.pro;

import java.util.ArrayDeque;
import java.util.Arrays;

/** UI-free hex-grid state; immutable input snapshots, deep-copied by simulator. */
public final class BoardState {
    public static final int ROWS = 24, COLS = 13;
    public static final int EMPTY = 0;
    public static final int RED = 1, YELLOW = 2, GREEN = 3, CYAN = 4, BLUE = 5, PINK = 6;
    // Canonical coordinates extracted from the user's 830 x 1848 gameplay frames.
    public static final double WIDTH=830, HEIGHT=1848, R=30.5, DX=64.0, DY=55.0;
    public static final double TOP_X=32, TOP_Y=274, SHOOTER_X=415, SHOOTER_Y=1656, DANGER_Y=1549;
    public final int[][] cells = new int[ROWS][COLS];
    public final boolean[][] special = new boolean[ROWS][COLS];
    public double x0 = TOP_X, y0 = TOP_Y, dx = DX, dy = DY;
    public int current = EMPTY, next = EMPTY;
    public boolean reliable;
    public int count;
    public long hash;

    public static double cx(BoardState b, int r,int c){return b.x0 + b.dx*(c + ((r&1)==0?0:.5));}
    public static double cy(BoardState b,int r){return b.y0 + b.dy*r;}
    public BoardState copy() {
        BoardState b=new BoardState();
        for(int r=0;r<ROWS;r++){System.arraycopy(cells[r],0,b.cells[r],0,COLS);System.arraycopy(special[r],0,b.special[r],0,COLS);}
        b.x0=x0;b.y0=y0;b.dx=dx;b.dy=dy;b.current=current;b.next=next;b.reliable=reliable;b.count=count;b.hash=hash;
        return b;
    }
    public boolean inside(int r,int c){return r>=0&&r<ROWS&&c>=0&&c<COLS&&cx(this,r,c)>10&&cx(this,r,c)<WIDTH-10;}
    /** six neighbors: odd rows are offset right by half a column. */
    public int[][] neighbors(int r,int c) {
        if((r&1)==0) return new int[][]{{r,c-1},{r,c+1},{r-1,c-1},{r-1,c},{r+1,c-1},{r+1,c}};
        return new int[][]{{r,c-1},{r,c+1},{r-1,c},{r-1,c+1},{r+1,c},{r+1,c+1}};
    }
    public boolean[][] connectedTop(){
        boolean[][] seen=new boolean[ROWS][COLS]; ArrayDeque<Integer> q=new ArrayDeque<>();
        for(int c=0;c<COLS;c++) if(cells[0][c]!=0 && inside(0,c)){seen[0][c]=true;q.add(c);}
        while(!q.isEmpty()){
            int i=q.removeFirst(),r=i/COLS,c=i%COLS;
            for(int[] a:neighbors(r,c)){int nr=a[0],nc=a[1];if(inside(nr,nc)&&!seen[nr][nc]&&cells[nr][nc]!=0){seen[nr][nc]=true;q.add(nr*COLS+nc);}}
        }
        return seen;
    }
    public double deepestY(){double y=0;for(int r=0;r<ROWS;r++)for(int c=0;c<COLS;c++)if(cells[r][c]!=0)y=Math.max(y,cy(this,r));return y;}
    public int dangerCount(double y) {int n=0;for(int r=0;r<ROWS;r++)for(int c=0;c<COLS;c++)if(cells[r][c]!=0&&cy(this,r)>=y)n++;return n;}
    public int occupiedCount(){int n=0;for(int[] a:cells)for(int v:a)if(v!=0)n++;return n;}
    public int rootCount(){int n=0;for(int v:cells[0])if(v!=0)n++;return n;}
    public void recalcHash(){long h=1469598103934665603L;for(int[] row:cells)for(int v:row){h^=v;h*=1099511628211L;}hash=h;count=occupiedCount();}
}
