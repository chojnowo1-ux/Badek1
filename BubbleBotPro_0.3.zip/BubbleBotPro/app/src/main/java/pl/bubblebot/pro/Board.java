package pl.bubblebot.pro;

import java.util.ArrayList;
import java.util.List;

/** Pure Java hex board: 13 cells on even rows, 12 cells on odd rows. */
public final class Board {
    public static final int EMPTY = -1, INVALID = -2;
    public static final int BLUE = 0, GREEN = 1, PINK = 2, RED = 3;
    public static final int ROWS = 21, COLS = 13;
    public static final double SPACING_X = 64.0, SPACING_Y = 57.6;
    public final int[][] cells = new int[ROWS][COLS];
    public final boolean[][] bonusX2 = new boolean[ROWS][COLS];
    public final double topY;
    public final int phase;
    public int occupied;

    public Board(double topY, int phase) {
        this.topY = topY;
        this.phase = phase;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                cells[row][col] = valid(row, col) ? EMPTY : INVALID;
            }
        }
    }
    public boolean valid(int r, int c) { return r >= 0 && r < ROWS && c >= 0 && c < COLS && !(((r + phase) & 1) == 1 && c == 12); }
    public double x(int r, int c) { return (((r + phase) & 1) == 0 ? 32 : 64) + SPACING_X * c; }
    public double y(int r) { return topY + SPACING_Y * r; }
    public Board copy() {
        Board b = new Board(topY, phase);
        for (int r = 0; r < ROWS; r++) System.arraycopy(cells[r], 0, b.cells[r], 0, COLS);
        for (int r = 0; r < ROWS; r++) System.arraycopy(bonusX2[r], 0, b.bonusX2[r], 0, COLS);
        b.occupied = occupied;
        return b;
    }
    public int neighbours(int r, int c, int[][] out) {
        int n = 0;
        double xx = x(r, c), yy = y(r);
        for (int rr = Math.max(0,r-1); rr <= Math.min(ROWS-1,r+1); rr++) {
            for (int cc = Math.max(0,c-1); cc <= Math.min(COLS-1,c+1); cc++) {
                if (!valid(rr,cc) || (rr == r && cc == c)) continue;
                double dx = x(rr,cc)-xx, dy = y(rr)-yy;
                if (dx*dx+dy*dy < 74*74) {out[n][0] = rr; out[n][1] = cc; n++;}
            }
        }
        return n;
    }
    public boolean adjacentOccupied(int r, int c) {
        if (r == 0) return true;
        int[][] out = new int[6][2]; int n = neighbours(r,c,out);
        for(int i=0;i<n;i++) if(cells[out[i][0]][out[i][1]] >= 0) return true;
        return false;
    }
}
