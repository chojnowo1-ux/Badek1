package pl.bubblebot.pro;

import android.graphics.Bitmap;
import java.util.Arrays;

/** Color + lattice detection. Grid sampling excludes the aim dots and falling balls.
 * Screen normalized to gameplay capture at 830 x 1848, no OCR or network.
 */
public final class GameVision {
    private static final int W=830,H=1848;
    private static boolean hasAnchor=false;
    private static int previousOffset=0;
    private static double previousY=274;
    private static final int[] SAMPLES={0,-7,0,7,0,0,-7,0,7,0};

    public static BoardState read(Bitmap screenshot) {
        Bitmap b=Bitmap.createScaledBitmap(screenshot,W,H,true);
        try {
            BoardState best=new BoardState();
            double scoreBest=Double.NEGATIVE_INFINITY;
            // Calibrate both hex-grid orientations. Adding a ceiling row flips the
            // lattice stagger, which the fixed old calibration could not track.
            // The vertical origin also varies with the animation/HUD position.
            for(int stagger=0;stagger<=1;stagger++)
                for(int y=248;y<=288;y+=4)
                    for(int x=28;x<=36;x+=4){
                        BoardState t=build(b,x,y,stagger,false);
                        double quality=anchorQuality(b,t)-Math.abs(x-32)*0.3;
                        if(hasAnchor)quality-=Math.abs(y-previousY)*0.2+(stagger!=previousOffset?9:0);
                        if(quality>scoreBest){scoreBest=quality;best=t;}
                    }
            best=build(b,best.x0,best.y0,best.firstRowOffset,true);
            best.pruneDetached();
            best.current=ballColor(b,415,1652);
            best.next=ballColor(b,360,1691);
            // Return no plan on opaque overlays, menu, or transitioning animations.
            best.reliable=best.rootCount()>=5 && best.count>=10 && best.current!=0;
            best.recalcHash();
            if(best.reliable){previousOffset=best.firstRowOffset;previousY=best.y0;hasAnchor=true;}
            return best;
        } finally {if(b!=screenshot)b.recycle();}
    }
    private static BoardState build(Bitmap bmp,double x0,double y0,int stagger,boolean full){
        BoardState result=new BoardState();result.x0=x0;result.y0=y0;result.firstRowOffset=stagger;
        int maxRows=full?BoardState.ROWS:Math.min(8,BoardState.ROWS);
        for(int r=0;r<maxRows;r++)for(int c=0;c<BoardState.COLS;c++){
            if(!result.inside(r,c))continue;
            int x=(int)Math.round(BoardState.cx(result,r,c)), y=(int)Math.round(BoardState.cy(result,r));
            if(y>BoardState.DANGER_Y-6)continue;
            int color=ballColor(bmp,x,y);
            result.cells[r][c]=color;
            if(color!=0)result.count++;
        }
        return result;
    }
    private static double anchorQuality(Bitmap b,BoardState t){
        double score=0;
        // Centered balls should have the same hue 15px up/down and left/right;
        // sampling a ball's edge must not win over the actual hex-lattice center.
        for(int r=0;r<8;r++)for(int c=0;c<BoardState.COLS;c++){
            if(t.cells[r][c]==0)continue;
            int x=(int)Math.round(BoardState.cx(t,r,c));
            int y=(int)Math.round(BoardState.cy(t,r));
            if(x<25||x>=W-25||y<25||y>=H-25)continue;
            int color=t.cells[r][c];
            score+=3;
            if(classify(b.getPixel(x,y))==color)score+=2;
            if(classify(b.getPixel(x+16,y))==color)score+=2;
            if(classify(b.getPixel(x-16,y))==color)score+=2;
            if(classify(b.getPixel(x,y+16))==color)score+=2;
            if(classify(b.getPixel(x,y-16))==color)score+=2;
            if(classify(b.getPixel(x,y+24))==color)score+=1;
            if(classify(b.getPixel(x,y-24))==color)score+=1;
        }
        return score+5*t.rootCount();
    }
    private static int ballColor(Bitmap b,int x,int y){
        if(x<10||x>=W-10||y<10||y>=H-10)return 0;
        int[] votes=new int[7];
        for(int i=0;i<SAMPLES.length;i+=2){
            int v=classify(b.getPixel(x+SAMPLES[i],y+SAMPLES[i+1]));
            if(v>0)votes[v]++;
        }
        int best=0,n=0;for(int c=1;c<=6;c++)if(votes[c]>n){best=c;n=votes[c];}
        if(n<3)return 0;
        // The aim guide is made of tiny colored dots (~6–9px radius) and was
        // being mistaken for real bubbles (~30px radius). Real bubbles still
        // have the same hue at least 15px away from their center.
        int wide=0;
        if(classify(b.getPixel(x-15,y))==best)wide++;
        if(classify(b.getPixel(x+15,y))==best)wide++;
        if(classify(b.getPixel(x,y-15))==best)wide++;
        if(classify(b.getPixel(x,y+15))==best)wide++;
        return wide>=2?best:0;
    }
    private static int classify(int argb){
        int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;
        // Dominant-channel gates also reject the bright red loss-warning gradient.
        if(r>155 && r>g*1.45 && g>=25 && g<138 && b<110)return BoardState.RED;
        if(r>175&&g>145&&b<150&&r>g*.96)return BoardState.YELLOW;
        if(g>135&&g>r*1.28&&g>b*1.20)return BoardState.GREEN;
        if(g>135&&b>125&&r<135&&g>b*.72)return BoardState.CYAN;
        if(b>150&&g>65&&g<200&&r<120&&b>g*1.12)return BoardState.BLUE;
        if(r>130&&b>118&&g<155&&r>g*1.24&&b>g*1.15)return BoardState.PINK;
        return 0;
    }
}
