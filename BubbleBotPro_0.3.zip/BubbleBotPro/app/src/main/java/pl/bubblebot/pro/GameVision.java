package pl.bubblebot.pro;

import android.graphics.Bitmap;
import java.util.Arrays;

/** Color + lattice detection. Grid sampling excludes the aim dots and falling balls.
 * Screen normalized to gameplay capture at 830 x 1848, no OCR or network.
 */
public final class GameVision {
    private static final int W=830,H=1848;
    private static final int[] SAMPLES={0,-7,0,7,0,0,-7,0,7,0};

    public static BoardState read(Bitmap screenshot) {
        Bitmap b=Bitmap.createScaledBitmap(screenshot,W,H,true);
        try {
            BoardState best=new BoardState();
            int scoreBest=-1;
            // Keep anchors near the observed board geometry, but tolerate subpixel / HUD shifts.
            for(int dy=-7;dy<=7;dy+=2) for(int dx=-4;dx<=4;dx+=2){
                BoardState t=build(b,32+dx,274+dy,false);
                int quality=t.count + 2*t.rootCount();
                if(quality>scoreBest){scoreBest=quality;best=t;}
            }
            best=build(b,best.x0,best.y0,true);
            best.current=ballColor(b,415,1652);
            best.next=ballColor(b,360,1691);
            // Return no plan on opaque overlays, menu, or transitioning animations.
            best.reliable=best.rootCount()>=5 && best.count>=10 && best.current!=0;
            best.recalcHash();
            return best;
        } finally {if(b!=screenshot)b.recycle();}
    }
    private static BoardState build(Bitmap bmp,double x0,double y0,boolean full){
        BoardState result=new BoardState();result.x0=x0;result.y0=y0;
        int maxRows=full?BoardState.ROWS:Math.min(8,BoardState.ROWS);
        for(int r=0;r<maxRows;r++)for(int c=0;c<BoardState.COLS;c++){
            if(!result.inside(r,c))continue;
            int x=(int)Math.round(BoardState.cx(result,r,c)), y=(int)Math.round(BoardState.cy(result,r));
            if(y>BoardState.DANGER_Y-6)continue;
            int color=ballColor(bmp,x,y);
            result.cells[r][c]=color;
            if(color!=0)result.count++;
        }
        return result;
    }
    private static int ballColor(Bitmap b,int x,int y){
        if(x<10||x>=W-10||y<10||y>=H-10)return 0;
        int[] votes=new int[7];
        for(int i=0;i<SAMPLES.length;i+=2){
            int v=classify(b.getPixel(x+SAMPLES[i],y+SAMPLES[i+1]));
            if(v>0)votes[v]++;
        }
        int best=0,n=0;for(int c=1;c<=6;c++)if(votes[c]>n){best=c;n=votes[c];}
        return n>=3?best:0;
    }
    private static int classify(int argb){
        int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;
        // Dominant-channel gates also reject the bright red loss-warning gradient.
        if(r>155 && r>g*1.45 && g>=25 && g<138 && b<110)return BoardState.RED;
        if(r>175&&g>145&&b<150&&r>g*.96)return BoardState.YELLOW;
        if(g>135&&g>r*1.28&&g>b*1.20)return BoardState.GREEN;
        if(g>135&&b>125&&r<135&&g>b*.72)return BoardState.CYAN;
        if(b>150&&g>65&&g<200&&r<120&&b>g*1.12)return BoardState.BLUE;
        if(r>130&&b>118&&g<155&&r>g*1.24&&b>g*1.15)return BoardState.PINK;
        return 0;
    }
}
