package pl.bubblebot.pro;

/** Recognises the specific "PRYWATNY TURNIEJ / GRAJ" result menu from the video. */
public final class MenuDetector {
    private static int pixel(BoardDetector.Pixels p,int x,int y) {
        x=(int)Math.round(x*p.width()/864.0);y=(int)Math.round(y*p.height()/1920.0);
        if(x<0||y<0||x>=p.width()||y>=p.height())return 0;
        return p.argb(x,y);
    }
    private static boolean green(int c){int r=(c>>16)&255,g=(c>>8)&255,b=c&255;return g>155&&g>r*1.65&&g>b*2.3;}
    private static boolean blue(int c){int r=(c>>16)&255,g=(c>>8)&255,b=c&255;return b>155 && b>r*2 && g>65;}
    private static boolean yellow(int c){int r=(c>>16)&255,g=(c>>8)&255,b=c&255;return r>210 && g>145 && b<100;}
    public static boolean replayVisible(BoardDetector.Pixels p) {
        if(p.width()<400 || p.height()<750)return false;
        // Triangulated pattern: yellow trophy, broad green GRAJ button,
        // blue MENU GŁÓWNE below. Avoids blindly tapping other apps.
        return yellow(pixel(p,420,350)) && yellow(pixel(p,475,390))
                && green(pixel(p,295,1370)) && green(pixel(p,520,1370))
                && green(pixel(p,295,1415)) && green(pixel(p,520,1415))
                && blue(pixel(p,295,1500)) && blue(pixel(p,520,1500));
    }
}
