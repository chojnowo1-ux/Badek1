package pl.bubblebot.pro;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Precision shot planning: continuous ray/circle collisions (no 4 px frame
 * quantisation), exact side-wall reflections, and fine-angle robustness scan.
 * Coordinates are normalised to the 864 x 1920 reference image.
 */
public final class ShotPlanner {
    public static final class Shot {
        public final double angleDegrees, targetX, targetY, score;
        public final int removed, dropped, bounceCount;
        public final int landingRow, landingCol;
        final Board after;
        Shot(double angleDegrees, double targetX, double targetY,
             double score, int removed, int dropped, int bounces, Board after,
             int landingRow, int landingCol) {
            this.angleDegrees=angleDegrees; this.targetX=targetX;
            this.targetY=targetY; this.score=score;
            this.removed=removed; this.dropped=dropped; this.bounceCount=bounces;
            this.after=after;
            this.landingRow=landingRow;this.landingCol=landingCol;
        }
        Shot withScore(double value){
            return new Shot(angleDegrees,targetX,targetY,value,removed,dropped,bounceCount,after,landingRow,landingCol);
        }
    }
    private static boolean hasPop(List<Shot> candidates) {
        for(Shot s:candidates)if(s.removed>=3)return true;
        return false;
    }
    private static final double SHOT_X=432, SHOT_Y=1721;
    private static final double LEFT=32, RIGHT=832, COLLISION_RADIUS=60;
    private static final double EPS=0.00001;
    // Normalised (864x1920) position of the fatal purple horizontal line.
    // A bubble touching this line ends the game. Its radius is about 29px.
    private static final double LOSS_LINE_Y=1607;
    private static final double BALL_RADIUS=29;
    private static final double DANGER_BEGINS_Y=1110;
    private static final double CRITICAL_LOWEST_Y=1370;

    /** Increasing penalty for bubbles close to the game-over line. */
    static double boardDanger(Board board) {
        double sum=0;
        for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++) {
            if(board.cells[r][c]<0)continue;
            double y=board.y(r);
            double t=Math.max(0,(y-DANGER_BEGINS_Y)/(LOSS_LINE_Y-DANGER_BEGINS_Y));
            sum+=350*t*t+1050*t*t*t*t;
            if(y>1420)sum+=(y-1420)*7;
            if(y+BALL_RADIUS>=LOSS_LINE_Y)sum+=40000;
        }
        return sum;
    }
    static double deepestY(Board board) {
        for(int r=Board.ROWS-1;r>=0;r--)
            for(int c=0;c<Board.COLS;c++)if(board.cells[r][c]>=0)return board.y(r);
        return board.topY;
    }


    public Shot choose(Board board,int ball) { return choose(board,ball,Board.EMPTY); }

    public Shot choose(Board board,int ball,int next) {
        if(ball<0)return null;
        List<Shot> coarse=new ArrayList<>();
        for(int i=-79;i<=79;i++){
            Shot shot=simulate(board,ball,i);
            if(shot!=null)coarse.add(shot);
        }
        coarse.sort(Comparator.comparingDouble((Shot s)->s.score).reversed());
        if(coarse.isEmpty())return null;

        // When nothing can be popped immediately, use the visible NEXT
        // bubble to plan a two-shot setup rather than firing at random.
        if(next>=0 && !hasPop(coarse)) {
            List<Shot> planned=new ArrayList<>();
            int examined=0;
            for(Shot candidate:coarse) {
                if(candidate.after==null || candidate.removed!=0)continue;
                double nextBest=Double.NEGATIVE_INFINITY;
                for(int angle=-78;angle<=78;angle+=3){
                    Shot follow=simulate(candidate.after,next,angle);
                    if(follow!=null && follow.score>nextBest)nextBest=follow.score;
                }
                // A modest weight avoids trading away imminent survival
                // for a speculative second-shot combo.
                double planningBonus=nextBest>0?Math.min(1600,nextBest)*0.38:0;
                planned.add(candidate.withScore(candidate.score+planningBonus));
                if(++examined>=14)break;
            }
            if(!planned.isEmpty()){
                coarse.addAll(planned);
                coarse.sort(Comparator.comparingDouble((Shot s)->s.score).reversed());
            }
        }
        Shot best=null;
        double bestRobust=Double.NEGATIVE_INFINITY;
        int seeds=0;
        List<Double> selectedAngles=new ArrayList<>();
        for(Shot seed:coarse){
            boolean nearby=false;
            for(double angle:selectedAngles)if(Math.abs(seed.angleDegrees-angle)<1.8){nearby=true;break;}
            if(nearby)continue;
            selectedAngles.add(seed.angleDegrees);
            seeds++;
            Shot seedBase=simulate(board,ball,seed.angleDegrees);
            double seedSetupBonus=seedBase==null?0:Math.max(0,seed.score-seedBase.score);
            // At the very top of a narrow opening, 1 degree can mean missing.
            // Refine 0.15 degree increments and prefer trajectories that remain
            // good when angle changes by +/- 0.3 degrees.
            for(int i=-7;i<=7;i++){
                double angle=seed.angleDegrees+i*0.15;
                if(angle < -80 || angle > 80)continue;
                Shot shot=simulate(board,ball,angle);
                if(shot==null)continue;
                Shot left=simulate(board,ball,angle-0.30);
                Shot right=simulate(board,ball,angle+0.30);
                double minimum=Math.min(left==null?-90:left.score,right==null?-90:right.score);
                double robust=0.82*shot.score+0.18*minimum;
                if(shot.landingRow==seed.landingRow && shot.landingCol==seed.landingCol)
                    robust+=seedSetupBonus*0.75;
                // If one side produces a different result, prefer a safe centre.
                if(left!=null && right!=null && shot.removed>0 &&
                   (left.removed==0 || right.removed==0)) robust-=60;
                if(best==null || robust>bestRobust){best=shot;bestRobust=robust;}
            }
            if(seeds>=10)break;
        }
        return best==null?coarse.get(0):best;
    }

    private Shot simulate(Board src,int ball,double angle){
        double radians=Math.toRadians(angle);
        double dx=Math.sin(radians),dy=-Math.cos(radians);
        double x=SHOT_X,y=SHOT_Y,impactX=0,impactY=0;
        int bounces=0;
        boolean collided=false;
        // Exact circle collision avoids tunnelling through bubbles at steep
        // angles, and unlike a fixed-step loop, handles long reflected rays.
        for(int segment=0;segment<12;segment++){
            double toTop=(src.topY-y)/dy;
            if(toTop<0)toTop=Double.POSITIVE_INFINITY;
            double toWall=Double.POSITIVE_INFINITY;
            if(dx>EPS)toWall=(RIGHT-x)/dx;
            else if(dx<-EPS)toWall=(LEFT-x)/dx;
            if(toWall<0)toWall=Double.POSITIVE_INFINITY;
            double maxTravel=Math.min(toTop,toWall);
            double firstHit=maxTravel+EPS;
            for(int r=0;r<Board.ROWS;r++){
                for(int c=0;c<Board.COLS;c++){
                    if(src.cells[r][c]<0)continue;
                    double vx=src.x(r,c)-x,vy=src.y(r)-y;
                    double proj=vx*dx+vy*dy;
                    if(proj<0 || proj-COLLISION_RADIUS>firstHit)continue;
                    double perp2=vx*vx+vy*vy-proj*proj;
                    double rr=COLLISION_RADIUS*COLLISION_RADIUS;
                    if(perp2>rr)continue;
                    double t=proj-Math.sqrt(Math.max(0,rr-perp2));
                    if(t>EPS && t<firstHit)firstHit=t;
                }
            }
            if(firstHit<maxTravel){
                impactX=x+dx*firstHit;impactY=y+dy*firstHit;
                collided=true;break;
            }
            if(toTop<=toWall){
                impactX=x+dx*toTop;impactY=src.topY;
                collided=true;break;
            }
            // Mirror trajectory at centre-of-ball wall limits.
            x+=dx*toWall;y+=dy*toWall;
            dx=-dx;bounces++;
        }
        if(!collided)return null;
        int sr=-1,sc=-1;
        double minD=Double.POSITIVE_INFINITY;
        for(int r=0;r<Board.ROWS;r++){
            if(Math.abs(src.y(r)-impactY)>100)continue;
            for(int c=0;c<Board.COLS;c++){
                if(src.cells[r][c]!=Board.EMPTY || !src.adjacentOccupied(r,c))continue;
                double ddx=src.x(r,c)-impactX,ddy=src.y(r)-impactY;
                double dd=ddx*ddx+ddy*ddy;
                if(dd<minD){sr=r;sc=c;minD=dd;}
            }
        }
        if(sr<0 || minD>98*98)return null;
        Board board=src.copy();board.cells[sr][sc]=ball;
        boolean[][] same=new boolean[Board.ROWS][Board.COLS];
        ArrayDeque<int[]> q=new ArrayDeque<>();
        q.add(new int[]{sr,sc});same[sr][sc]=true;
        int[][] offsets=new int[6][2];
        int group=0;
        while(!q.isEmpty()){
            int[] a=q.removeFirst();group++;
            int n=board.neighbours(a[0],a[1],offsets);
            for(int i=0;i<n;i++){
                int rr=offsets[i][0],cc=offsets[i][1];
                if(!same[rr][cc] && board.cells[rr][cc]==ball){
                    same[rr][cc]=true;q.add(new int[]{rr,cc});
                }
            }
        }
        int removed=0,dropped=0;
        boolean gotX2=false;
        double dropWeighted=0;
        if(group>=3){
            for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
                if(same[r][c]){
                    if(board.bonusX2[r][c])gotX2=true;
                    board.cells[r][c]=Board.EMPTY;removed++;
                }
            }
            boolean[][] connected=new boolean[Board.ROWS][Board.COLS];
            for(int c=0;c<Board.COLS;c++)if(board.cells[0][c]>=0){
                connected[0][c]=true;q.add(new int[]{0,c});
            }
            while(!q.isEmpty()){
                int[] a=q.removeFirst();
                int n=board.neighbours(a[0],a[1],offsets);
                for(int i=0;i<n;i++){
                    int rr=offsets[i][0],cc=offsets[i][1];
                    if(!connected[rr][cc] && board.cells[rr][cc]>=0){
                        connected[rr][cc]=true;q.add(new int[]{rr,cc});
                    }
                }
            }
            for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
                if(board.cells[r][c]>=0 && !connected[r][c]){
                    dropped++;double xx=board.x(r,c);
                    double zone=xx<172||xx>=660?50:xx<340||xx>=496?100:250;
                    dropWeighted+=zone/100.0;
                    board.cells[r][c]=Board.EMPTY; // actually falls, not a retained obstacle
                }
            }
        }
        double score=(removed*95+dropped*115+dropWeighted*35)*(gotX2?2:1);
        if(removed==0)score=-55+Math.min(35,group*14)-sr*0.6;
        score-=bounces*1.8;
        score-=Math.abs(angle)*0.025;

        // Winning is more important than short-term points: preferentially
        // eliminate the low hanging bubbles, or cut their connection to the
        // ceiling. Avoid shots that make the lowest row creep downward.
        double beforeDeep=deepestY(src), afterDeep=deepestY(board);
        double urgency=beforeDeep>=CRITICAL_LOWEST_Y?3.8:beforeDeep>=1240?2.1:0.8;
        score+=(boardDanger(src)-boardDanger(board))*urgency;
        if(afterDeep<beforeDeep && beforeDeep>1240)
            score+=(beforeDeep-afterDeep)* (beforeDeep>=CRITICAL_LOWEST_Y?23:10);
        if(afterDeep>beforeDeep && afterDeep>1240)
            score-=(afterDeep-beforeDeep)*(afterDeep>=CRITICAL_LOWEST_Y?32:12);
        if(afterDeep+BALL_RADIUS>=LOSS_LINE_Y)
            score-=120000;
        // If this is just a setup (no pop), avoid attaching new balls deep
        // in the pile, especially where space is about to run out.
        if(removed==0)score-=sr*3.0;

        // Aimed tap must be on the original outgoing ray, NOT at its final
        // collision cell, especially when a side-wall reflection is used.
        double tapY=690;
        double distance=(SHOT_Y-tapY)/Math.cos(radians);
        double tapX=SHOT_X+Math.sin(radians)*distance;
        if(tapX<100 || tapX>764){
            distance=200;
            tapY=SHOT_Y-200*Math.cos(radians);
            tapX=SHOT_X+200*Math.sin(radians);
        }
        return new Shot(angle,tapX,tapY,score,removed,dropped,bounces,board,sr,sc);
    }
}
