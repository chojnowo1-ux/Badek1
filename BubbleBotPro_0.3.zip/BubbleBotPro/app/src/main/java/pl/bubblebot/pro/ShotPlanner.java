package pl.bubblebot.pro;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Precision shot planning: continuous ray/circle collisions (no 4 px frame
 * quantisation), exact side-wall reflections, and fine-angle robustness scan.
 * Coordinates are normalised to the 864 x 1920 reference image.
 */
public final class ShotPlanner {
    public static final class Shot {
        public final double angleDegrees, targetX, targetY, score;
        public final int removed, dropped, bounceCount;
        Shot(double angleDegrees, double targetX, double targetY,
             double score, int removed, int dropped, int bounces) {
            this.angleDegrees=angleDegrees; this.targetX=targetX;
            this.targetY=targetY; this.score=score;
            this.removed=removed; this.dropped=dropped; this.bounceCount=bounces;
        }
    }
    private static final double SHOT_X=432, SHOT_Y=1721;
    private static final double LEFT=32, RIGHT=832, COLLISION_RADIUS=60;
    private static final double EPS=0.00001;

    public Shot choose(Board board,int ball) {
        if(ball<0)return null;
        List<Shot> coarse=new ArrayList<>();
        for(int i=-79;i<=79;i++){
            Shot shot=simulate(board,ball,i);
            if(shot!=null)coarse.add(shot);
        }
        coarse.sort(Comparator.comparingDouble((Shot s)->s.score).reversed());
        if(coarse.isEmpty())return null;
        Shot best=null;
        double bestRobust=Double.NEGATIVE_INFINITY;
        int seeds=0;
        List<Double> selectedAngles=new ArrayList<>();
        for(Shot seed:coarse){
            boolean nearby=false;
            for(double angle:selectedAngles)if(Math.abs(seed.angleDegrees-angle)<1.8){nearby=true;break;}
            if(nearby)continue;
            selectedAngles.add(seed.angleDegrees);
            seeds++;
            // At the very top of a narrow opening, 1 degree can mean missing.
            // Refine 0.15 degree increments and prefer trajectories that remain
            // good when angle changes by +/- 0.3 degrees.
            for(int i=-7;i<=7;i++){
                double angle=seed.angleDegrees+i*0.15;
                if(angle < -80 || angle > 80)continue;
                Shot shot=simulate(board,ball,angle);
                if(shot==null)continue;
                Shot left=simulate(board,ball,angle-0.30);
                Shot right=simulate(board,ball,angle+0.30);
                double minimum=Math.min(left==null?-90:left.score,right==null?-90:right.score);
                double robust=0.82*shot.score+0.18*minimum;
                // If one side produces a different result, prefer a safe centre.
                if(left!=null && right!=null && shot.removed>0 &&
                   (left.removed==0 || right.removed==0)) robust-=60;
                if(best==null || robust>bestRobust){best=shot;bestRobust=robust;}
            }
            if(seeds>=10)break;
        }
        return best==null?coarse.get(0):best;
    }

    private Shot simulate(Board src,int ball,double angle){
        double radians=Math.toRadians(angle);
        double dx=Math.sin(radians),dy=-Math.cos(radians);
        double x=SHOT_X,y=SHOT_Y,impactX=0,impactY=0;
        int bounces=0;
        boolean collided=false;
        // Exact circle collision avoids tunnelling through bubbles at steep
        // angles, and unlike a fixed-step loop, handles long reflected rays.
        for(int segment=0;segment<12;segment++){
            double toTop=(src.topY-y)/dy;
            if(toTop<0)toTop=Double.POSITIVE_INFINITY;
            double toWall=Double.POSITIVE_INFINITY;
            if(dx>EPS)toWall=(RIGHT-x)/dx;
            else if(dx<-EPS)toWall=(LEFT-x)/dx;
            if(toWall<0)toWall=Double.POSITIVE_INFINITY;
            double maxTravel=Math.min(toTop,toWall);
            double firstHit=maxTravel+EPS;
            for(int r=0;r<Board.ROWS;r++){
                for(int c=0;c<Board.COLS;c++){
                    if(src.cells[r][c]<0)continue;
                    double vx=src.x(r,c)-x,vy=src.y(r)-y;
                    double proj=vx*dx+vy*dy;
                    if(proj<0 || proj-COLLISION_RADIUS>firstHit)continue;
                    double perp2=vx*vx+vy*vy-proj*proj;
                    double rr=COLLISION_RADIUS*COLLISION_RADIUS;
                    if(perp2>rr)continue;
                    double t=proj-Math.sqrt(Math.max(0,rr-perp2));
                    if(t>EPS && t<firstHit)firstHit=t;
                }
            }
            if(firstHit<maxTravel){
                impactX=x+dx*firstHit;impactY=y+dy*firstHit;
                collided=true;break;
            }
            if(toTop<=toWall){
                impactX=x+dx*toTop;impactY=src.topY;
                collided=true;break;
            }
            // Mirror trajectory at centre-of-ball wall limits.
            x+=dx*toWall;y+=dy*toWall;
            dx=-dx;bounces++;
        }
        if(!collided)return null;
        int sr=-1,sc=-1;
        double minD=Double.POSITIVE_INFINITY;
        for(int r=0;r<Board.ROWS;r++){
            if(Math.abs(src.y(r)-impactY)>100)continue;
            for(int c=0;c<Board.COLS;c++){
                if(src.cells[r][c]!=Board.EMPTY || !src.adjacentOccupied(r,c))continue;
                double ddx=src.x(r,c)-impactX,ddy=src.y(r)-impactY;
                double dd=ddx*ddx+ddy*ddy;
                if(dd<minD){sr=r;sc=c;minD=dd;}
            }
        }
        if(sr<0 || minD>98*98)return null;
        Board board=src.copy();board.cells[sr][sc]=ball;
        boolean[][] same=new boolean[Board.ROWS][Board.COLS];
        ArrayDeque<int[]> q=new ArrayDeque<>();
        q.add(new int[]{sr,sc});same[sr][sc]=true;
        int[][] offsets=new int[6][2];
        int group=0;
        while(!q.isEmpty()){
            int[] a=q.removeFirst();group++;
            int n=board.neighbours(a[0],a[1],offsets);
            for(int i=0;i<n;i++){
                int rr=offsets[i][0],cc=offsets[i][1];
                if(!same[rr][cc] && board.cells[rr][cc]==ball){
                    same[rr][cc]=true;q.add(new int[]{rr,cc});
                }
            }
        }
        int removed=0,dropped=0;
        boolean gotX2=false;
        double dropWeighted=0;
        if(group>=3){
            for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
                if(same[r][c]){
                    if(board.bonusX2[r][c])gotX2=true;
                    board.cells[r][c]=Board.EMPTY;removed++;
                }
            }
            boolean[][] connected=new boolean[Board.ROWS][Board.COLS];
            for(int c=0;c<Board.COLS;c++)if(board.cells[0][c]>=0){
                connected[0][c]=true;q.add(new int[]{0,c});
            }
            while(!q.isEmpty()){
                int[] a=q.removeFirst();
                int n=board.neighbours(a[0],a[1],offsets);
                for(int i=0;i<n;i++){
                    int rr=offsets[i][0],cc=offsets[i][1];
                    if(!connected[rr][cc] && board.cells[rr][cc]>=0){
                        connected[rr][cc]=true;q.add(new int[]{rr,cc});
                    }
                }
            }
            for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
                if(board.cells[r][c]>=0 && !connected[r][c]){
                    dropped++;double xx=board.x(r,c);
                    double zone=xx<172||xx>=660?50:xx<340||xx>=496?100:250;
                    dropWeighted+=zone/100.0;
                }
            }
        }
        double score=(removed*95+dropped*115+dropWeighted*35)*(gotX2?2:1);
        if(removed==0)score=-55+Math.min(35,group*14)-sr*0.6;
        score-=bounces*1.8;
        score-=Math.abs(angle)*0.025;
        // Aimed tap must be on the original outgoing ray, NOT at its final
        // collision cell, especially when a side-wall reflection is used.
        double tapY=690;
        double distance=(SHOT_Y-tapY)/Math.cos(radians);
        double tapX=SHOT_X+Math.sin(radians)*distance;
        if(tapX<100 || tapX>764){
            distance=200;
            tapY=SHOT_Y-200*Math.cos(radians);
            tapX=SHOT_X+200*Math.sin(radians);
        }
        return new Shot(angle,tapX,tapY,score,removed,dropped,bounces);
    }
}
