package pl.bubblebot.pro;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Comparator;
import java.util.List;

/** Geometry-aware one-shot lookahead, six-connected matching, dangling-cluster drops.
 * No game/Android dependencies; exercise with javac tests/run_tests.sh.
 */
public final class TrajectoryPlanner {
    public static final class Shot {
        public double angle, score; public int row,col,popped,dropped; public double afterDeepest;
        public String reason;
    }
    private static final class Outcome {
        int popped,dropped,priorBottom,afterBottom; double deepest,weightedDangerBefore,weightedDangerAfter; int colorNeighbors;
    }
    private static final int[][] JITTER={{0,0}};

    /** Positive angle points right. Avoid shallow near-horizontal paths. */
    public static Shot choose(BoardState src) {
        if(src.current==0 || src.count==0) return null;
        final double oldDeep=src.deepestY(), line=BoardState.DANGER_Y, gap=line-oldDeep;
        final boolean emergency=gap<240, critical=gap<135;
        Shot best=null;
        // Many adjacent aim angles land in the same hex cell. Run the expensive
        // flood-fill simulation only once per distinct final destination.
        Map<Integer,Outcome> cached=new HashMap<>();
        // Trace 301 candidate rays. Direct and wall-bank paths are scored identically.
        for(int k=-150;k<=150;k++){
            double angle=Math.toRadians(k*.48); // -72° .. 72°
            Shot s=trace(src,angle);
            if(s!=null)s.angle=angle;
            if(s==null)continue;
            int key=s.row*BoardState.COLS+s.col;
            Outcome o=cached.get(key);
            if(o==null){o=evaluate(src,s.row,s.col);if(o!=null)cached.put(key,o);}
            if(o==null)continue;
            s.popped=o.popped;s.dropped=o.dropped;s.afterDeepest=o.deepest;
            // Difference in actual remaining danger determines survival, not the nearest visible hit.
            double deepGain=oldDeep-o.deepest;
            double dangerWeight=critical?195:emergency?110:40;
            double riskCount=(o.priorBottom-o.afterBottom)*dangerWeight;
            // Progressive cleanup: reward removing LOW bubbles even if the deepest tip on
            // the other side has not yet been removed. Critical to avert side-wall death.
            riskCount += (o.weightedDangerBefore-o.weightedDangerAfter)*(critical?95:emergency?60:24);
            double reward= o.popped*95 + o.dropped*150 + Math.max(0,deepGain)*(.22+(emergency?2.7:0.8));
            double penalty=0;
            if(o.popped==0){
                penalty += emergency?330:185;
                penalty += Math.max(0, -deepGain)*(emergency?5.0:2.2);
                // Prefer building same-color pairs over useless unmatched singles.
                penalty -= o.colorNeighbors*(src.next==src.current?125:45);
            }
            // If a shot extends below danger line, it is almost certainly terminal.
            if(o.deepest>=line-BoardState.R)penalty+=5000;
            if(o.deepest>line-145)penalty+=Math.pow((o.deepest-(line-145))/16,2)*(critical?100:40);
            if(o.deepest>oldDeep && emergency)penalty+=(o.deepest-oldDeep)*5;
            double safety=riskCount + reward-penalty;
            // Prefer reliable central trajectories when nearly equivalent.
            safety -= Math.abs(angle)*2.5;
            // Extra row-density risk, prevents growing tall tips during otherwise quiet play.
            s.score=safety;
            s.reason="zbite="+s.popped+", odciete="+s.dropped+", zagrozenie="+o.afterBottom;
            if(best==null || s.score>best.score)best=s;
        }
        return best;
    }
    public static Shot trace(BoardState b,double angle) {
        double vx=Math.sin(angle),vy=-Math.cos(angle);
        double x=BoardState.SHOOTER_X,y=BoardState.SHOOTER_Y;
        final double rad=BoardState.R, dx=2.6;
        for(int step=0;step<1100;step++) {
            x+=vx*dx; y+=vy*dx;
            if(x<rad){x=2*rad-x;vx=-vx;} else if(x>BoardState.WIDTH-rad){x=2*(BoardState.WIDTH-rad)-x;vx=-vx;}
            if(y<=b.y0){return snap(b,x,b.y0,0);}
            // Nearest grid row only; avoids O(24*13) every pixel step.
            int r0=(int)Math.round((y-b.y0)/b.dy);
            boolean collided=false;
            for(int r=Math.max(0,r0-1);r<=Math.min(BoardState.ROWS-1,r0+1)&&!collided;r++){
                for(int c=0;c<BoardState.COLS;c++){
                    if(!b.inside(r,c)||b.cells[r][c]==0)continue;
                    double tx=BoardState.cx(b,r,c),ty=BoardState.cy(b,r);
                    double dd=(tx-x)*(tx-x)+(ty-y)*(ty-y);
                    if(dd<=(2*rad-3)*(2*rad-3)){collided=true;break;}
                }
            }
            if(collided){return snap(b,x,y,1);}
        }
        return null;
    }
    private static Shot snap(BoardState b,double x,double y,int collision){
        double best=Double.POSITIVE_INFINITY;int br=-1,bc=-1;
        for(int r=0;r<BoardState.ROWS;r++){
            if(Math.abs(BoardState.cy(b,r)-y)>BoardState.R*3.5)continue;
            for(int c=0;c<BoardState.COLS;c++){
                if(!b.inside(r,c)||b.cells[r][c]!=0)continue;
                if(collision==0 && r!=0)continue;
                // A slot can only be populated adjacent to something fixed, except the ceiling.
                if(r!=0){boolean neighbor=false;for(int[] n:b.neighbors(r,c))if(b.inside(n[0],n[1])&&b.cells[n[0]][n[1]]!=0){neighbor=true;break;}if(!neighbor)continue;}
                double xx=BoardState.cx(b,r,c), yy=BoardState.cy(b,r);
                double d=(xx-x)*(xx-x)+(yy-y)*(yy-y);
                if(d<best){best=d;br=r;bc=c;}
            }
        }
        if(br<0)return null;
        Shot s=new Shot();s.row=br;s.col=bc;return s;
    }
    private static Outcome evaluate(BoardState src,int r,int c){
        if(!src.inside(r,c)||src.cells[r][c]!=0)return null;
        BoardState b=src.copy();
        Outcome o=new Outcome();o.priorBottom=b.dangerCount(BoardState.DANGER_Y-235);
        o.weightedDangerBefore=weightedDanger(b);
        b.cells[r][c]=src.current;
        boolean[][] visited=new boolean[BoardState.ROWS][BoardState.COLS];
        ArrayDeque<Integer> q=new ArrayDeque<>();q.add(r*BoardState.COLS+c);visited[r][c]=true;
        ArrayList<Integer> matching=new ArrayList<>();
        while(!q.isEmpty()){
            int v=q.removeFirst(),rr=v/BoardState.COLS,cc=v%BoardState.COLS;
            matching.add(v);
            for(int[] n:b.neighbors(rr,cc)){
                int nr=n[0],nc=n[1];
                if(b.inside(nr,nc)&&!visited[nr][nc]&&b.cells[nr][nc]==src.current){
                    visited[nr][nc]=true;q.add(nr*BoardState.COLS+nc);
                }
            }
        }
        o.colorNeighbors=matching.size()-1;
        if(matching.size()>=3){
            o.popped=matching.size();
            for(int v:matching)b.cells[v/BoardState.COLS][v%BoardState.COLS]=0;
            boolean[][] grounded=b.connectedTop();
            for(int ir=0;ir<BoardState.ROWS;ir++)for(int ic=0;ic<BoardState.COLS;ic++){
                if(b.cells[ir][ic]!=0&&!grounded[ir][ic]){b.cells[ir][ic]=0;o.dropped++;}
            }
        }
        o.deepest=b.deepestY();o.afterBottom=b.dangerCount(BoardState.DANGER_Y-235);
        o.weightedDangerAfter=weightedDanger(b);
        return o;
    }
    private static double weightedDanger(BoardState b){
        double total=0;
        for(int r=0;r<BoardState.ROWS;r++){
            double v=Math.max(0, (BoardState.cy(b,r)-(BoardState.DANGER_Y-500))/80.);
            double w=v*v;
            for(int c=0;c<BoardState.COLS;c++)if(b.cells[r][c]!=0)total+=w;
        }
        return total;
    }
}
