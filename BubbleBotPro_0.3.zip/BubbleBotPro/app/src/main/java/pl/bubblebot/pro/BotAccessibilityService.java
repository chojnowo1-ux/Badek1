package pl.bubblebot.pro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Uses only the Android Accessibility API: screenshot + one gesture at a time.
 * No persistent image storage, no internet access, no external automation tools.
 */
public final class BotAccessibilityService extends AccessibilityService {
    public static volatile BotAccessibilityService instance;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile boolean running=false;
    private boolean captureInFlight=false, gestureInFlight=false;
    private Button overlay;
    private WindowManager window;
    private long lastSignature=Long.MIN_VALUE;
    private long pendingSignature=Long.MIN_VALUE;
    private int stableCaptures=0;
    private int missed=0;
    private long lastReplayTap=0;
    private long lastShotAt=0;
    private int capturedWidth=864, capturedHeight=1920;
    private final Runnable captureRunnable=this::capture;

    public boolean isRunning(){return running;}
    @Override protected void onServiceConnected(){
        super.onServiceConnected();instance=this;showOverlay();
        Log.i("BubbleBot","Accessibility service connected");
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* no window text is collected */ }
    @Override public void onInterrupt() {stopBot();}
    public void startBot() {
        main.post(()->{
            running=true;lastSignature=Long.MIN_VALUE;
            pendingSignature=Long.MIN_VALUE;stableCaptures=0;
            missed=0;lastShotAt=0;
            setOverlay();main.removeCallbacks(captureRunnable);main.post(captureRunnable);
        });
    }
    public void stopBot(){
        running=false;
        main.post(()->{main.removeCallbacks(captureRunnable);setOverlay();});
    }
    private void schedule(long waitMs){
        if(!running)return;
        main.removeCallbacks(captureRunnable);
        main.postDelayed(captureRunnable,waitMs);
    }
    private void capture(){
        if(!running || captureInFlight || gestureInFlight)return;
        captureInFlight=true;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    captureInFlight=false;
                    HardwareBuffer buffer=result.getHardwareBuffer();
                    Bitmap raw=null,frame=null;
                    try {
                        raw=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());
                        if(raw!=null)frame=raw.copy(Bitmap.Config.ARGB_8888,false);
                    } catch(Exception e){Log.w("BubbleBot","Screenshot convert",e);}
                    finally {buffer.close(); if(raw!=null)raw.recycle();}
                    if(frame==null) {schedule(700);return;}
                    final Bitmap image=frame;
                    capturedWidth=image.getWidth();capturedHeight=image.getHeight();
                    worker.submit(()->process(image));
                }
                @Override public void onFailure(int code){
                    captureInFlight=false;
                    Log.w("BubbleBot","Screenshot error "+code);
                    // Android enforces a minimum interval between accessibility screenshots.
                    schedule(code==ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT?700:1400);
                }
            });
        } catch(Exception ex){captureInFlight=false;Log.e("BubbleBot","capture",ex);schedule(1200);}
    }
    private long signature(BoardDetector.Detection d){
        long h=1469598103934665603L;
        for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
            h^=(d.board.cells[r][c]+3);h*=1099511628211L;
        }
        h=(h^d.current)*1099511628211L;
        return (h^d.next)*1099511628211L;
    }
    private void process(Bitmap image){
        try {
            if(!running)return;
            BoardDetector.Pixels px=new BoardDetector.Pixels(){
                @Override public int width(){return image.getWidth();}
                @Override public int height(){return image.getHeight();}
                @Override public int argb(int x,int y){return image.getPixel(x,y);}
            };
            BoardDetector.Detection d=new BoardDetector(px).detect();
            if(!d.playable()){
                pendingSignature=Long.MIN_VALUE;stableCaptures=0;
                if(MenuDetector.replayVisible(px) &&
                        android.os.SystemClock.uptimeMillis()-lastReplayTap>8000){
                    lastReplayTap=android.os.SystemClock.uptimeMillis();
                    lastSignature=Long.MIN_VALUE;
                    main.post(()->tapScaled(416,1390,2200));
                    return;
                }
                missed++;main.post(()->schedule(missed>5?1500:650));return;
            }
            missed=0;
            long state=signature(d);
            // Ignore intermediary animation frames. Two identical captures
            // are required before planning a new shot, otherwise detached
            // falling balls may look like targets that do not exist.
            if(state!=pendingSignature){
                pendingSignature=state;stableCaptures=1;
                main.post(()->schedule(350));return;
            }
            stableCaptures++;
            if(state==lastSignature){
                // Never tap repeatedly during the previous shot's animation.
                // A quick recheck detects when a new bubble arrives.
                long age=android.os.SystemClock.uptimeMillis()-lastShotAt;
                main.post(()->schedule(age<3300?350:900));return;
            }
            ShotPlanner.Shot shot=new ShotPlanner().choose(d.board,d.current,d.next);
            if(shot==null){main.post(()->schedule(850));return;}
            lastSignature=state;
            pendingSignature=Long.MIN_VALUE;stableCaptures=0;
            lastShotAt=android.os.SystemClock.uptimeMillis();
            Log.i("BubbleBot",String.format(java.util.Locale.US,"balls=%d angle=%.1f removed=%d dropped=%d predicted=%.1f",d.count,shot.angleDegrees,shot.removed,shot.dropped,shot.score));
            main.post(()->fire(shot));
        }catch(Exception ex){Log.e("BubbleBot","analysis",ex);main.post(()->schedule(1100));}
        finally{image.recycle();}
    }
    private void fire(ShotPlanner.Shot shot){
        if(!running)return;
        float x=(float)(shot.targetX*capturedWidth/864.0);
        float y=(float)(shot.targetY*capturedHeight/1920.0);
        if(x<1 || x>capturedWidth-1 || y<180 || y>capturedHeight-70){schedule(900);return;}
        // Fast when the stack is close to the launcher, slightly slower on
        // long flights and rebounds. The next screenshot is still required.
        long nextCheck=shot.bounceCount>1?970:shot.bounceCount==1?850:730;
        gestureAt(x,y,nextCheck);
    }
    private void tapScaled(double x,double y,long afterMs) {
        if(!running)return;
        gestureAt((float)(x*capturedWidth/864.0),(float)(y*capturedHeight/1920.0),afterMs);
    }
    private void gestureAt(float x,float y,long afterMs){
        if(!running || gestureInFlight)return;
        Path p=new Path();p.moveTo(x,y);
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p,0,48);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(stroke).build();
        gestureInFlight=true;
        boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){gestureInFlight=false;schedule(afterMs);}
            @Override public void onCancelled(GestureDescription g){gestureInFlight=false;schedule(950);}
        },main);
        if(!accepted){gestureInFlight=false;lastSignature=Long.MIN_VALUE;schedule(950);}
    }
    private void showOverlay(){
        if(overlay!=null)return;
        window=(WindowManager)getSystemService(WINDOW_SERVICE);
        overlay=new Button(this);
        overlay.setTextColor(Color.WHITE);overlay.setTextSize(13);overlay.setAllCaps(false);
        overlay.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        int w=(int)(108*getResources().getDisplayMetrics().density), h=(int)(48*getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(w,h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.BOTTOM | Gravity.RIGHT;
        lp.x=(int)(10*getResources().getDisplayMetrics().density);
        lp.y=(int)(82*getResources().getDisplayMetrics().density);
        overlay.setOnClickListener(v->{if(isRunning())stopBot();else startBot();});
        setOverlay();
        try {window.addView(overlay,lp);}catch(Exception e){Log.e("BubbleBot","overlay",e);overlay=null;}
    }
    private void setOverlay(){if(overlay==null)return;overlay.setText(running?"■ STOP":"▶ AUTO");
        overlay.setBackgroundTintList(android.content.res.ColorStateList.valueOf(running?0xffcc2964:0xff3f9c43));}
    @Override public void onDestroy(){
        running=false;main.removeCallbacks(captureRunnable);
        if(overlay!=null && window!=null){try{window.removeView(overlay);}catch(Exception ignored) {}}
        worker.shutdownNow();instance=null;super.onDestroy();
    }
}
