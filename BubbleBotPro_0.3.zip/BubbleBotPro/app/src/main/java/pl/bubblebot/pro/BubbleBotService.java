package pl.bubblebot.pro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** API 30+ accessibility screenshot + gestures. All screenshot and touch data remain local. */
public class BubbleBotService extends AccessibilityService {
    private final Handler main=new Handler(Looper.getMainLooper());
    private WindowManager wm;private LinearLayout panel;private Button toggle;private TextView status;
    private boolean running=false,busy=false;
    private long lastShot=0;
    private long lastHash=0;private int lastColor=0,stability=0,shots=0;
    private int screenshotErrors=0;
    private boolean awaitingResult=false;private long pendingHash=0;private int pendingColor=0;
    private int swapSupported=0;private boolean pendingSwap=false;private int swapWantedColor=0;private long swapOldHash=0,swapAt=0;
    private final Runnable poll=new Runnable(){@Override public void run(){capture();}};

    @Override protected void onServiceConnected(){super.onServiceConnected();showControls();setStatus("Gotowy. Otworz gre i nacisnij AUTO");}
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt(){stop("Dostepnosc przerwana");}
    @Override public void onDestroy(){stop("Zatrzymano");if(panel!=null&&wm!=null)try{wm.removeView(panel);}catch(Exception ignored){}super.onDestroy();}

    private void showControls(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(7),dp(7),dp(7),dp(7));panel.setBackgroundColor(0xe5000e32);
        toggle=new Button(this);toggle.setAllCaps(false);toggle.setText("▶ AUTO 500K");
        toggle.setOnClickListener(v->{if(running)stop("Zatrzymany");else start();});
        status=new TextView(this);status.setTextColor(0xffffffff);status.setTextSize(10);status.setMaxLines(3);
        panel.addView(toggle,new LinearLayout.LayoutParams(dp(146),dp(43)));
        panel.addView(status,new LinearLayout.LayoutParams(dp(146),-2));
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(163),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.BOTTOM|Gravity.RIGHT;lp.x=5;lp.y=155;
        try{wm.addView(panel,lp);}catch(Exception e){panel=null;}
    }
    private int dp(float x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private void setStatus(String message){if(status!=null)status.setText(message);}
    private void start(){if(running)return;running=true;shots=0;lastShot=0;lastHash=0;lastColor=0;stability=0;
        screenshotErrors=0;awaitingResult=false;pendingSwap=false;swapSupported=0;if(toggle!=null)toggle.setText("■ STOP");setStatus("Analizuje plansze...");main.post(poll);}
    private void stop(String message){running=false;busy=false;main.removeCallbacks(poll);if(toggle!=null)toggle.setText("▶ AUTO 500K");setStatus(message);}
    private void next(long delay){if(running){main.removeCallbacks(poll);main.postDelayed(poll,delay);}}
    private void capture(){
        if(!running||busy)return;
        if(Build.VERSION.SDK_INT<30){stop("Wymagany Android 11+");return;}
        busy=true;
        try {takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult result){
                Bitmap copy=null;
                try{
                    HardwareBuffer buffer=result.getHardwareBuffer();
                    Bitmap hw=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());
                    if(hw!=null)copy=hw.copy(Bitmap.Config.ARGB_8888,false);
                    buffer.close();
                    if(copy!=null)process(copy); else setStatus("Brak bitmapy");
                    screenshotErrors=0;
                }catch(Exception ex){setStatus("Blad odczytu: "+ex.getClass().getSimpleName());}
                finally{if(copy!=null)copy.recycle();busy=false;next(390);}
            }
            @Override public void onFailure(int errorCode){
                busy=false;screenshotErrors++;setStatus("Zrzut ekranu: kod "+errorCode);
                if(screenshotErrors>=12)stop("Brak dostepu do obrazu - sprawdz usluge");else next(errorCode==ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT?700:500);
            }
        });}catch(Exception ex){busy=false;setStatus("Nie mozna wykonac zrzutu: "+ex.getMessage());next(750);}
    }
    private void process(Bitmap image){
        if(!running)return;
        BoardState board=GameVision.read(image);
        if(!board.reliable){stability=0;setStatus("Szukam planszy i koloru...\nStrzaly: "+shots);return;}
        long now=android.os.SystemClock.uptimeMillis();
        if(pendingSwap){
            if(board.current==swapWantedColor && board.hash==swapOldHash){
                swapSupported=1;pendingSwap=false;stability=0;setStatus("Zamiana koloru OK");return;
            }
            if(now-swapAt<1300){setStatus("Sprawdzam zamiane koloru...");return;}
            swapSupported=-1;pendingSwap=false;stability=0;setStatus("Brak zamiany - bez ponownych prob");return;
        }
        if(board.hash==lastHash&&board.current==lastColor){stability++;}else{stability=0;lastHash=board.hash;lastColor=board.current;}
        if(awaitingResult){
            if(board.hash!=pendingHash || board.current!=pendingColor){awaitingResult=false;stability=0;return;}
            if(now-lastShot>2700){stop("Brak zmiany po strzale - sprawdz celowanie");return;}
            setStatus("Czekam na efekt strzalu...");return;
        }
        if(stability<1 || now-lastShot<680){setStatus("Czekam az kulki sie zatrzymaja\nStrzaly: "+shots);return;}
        double gap=BoardState.DANGER_Y-board.deepestY();
        TrajectoryPlanner.Shot shot=TrajectoryPlanner.choose(board);
        if(shot==null){setStatus("Brak poprawnego strzalu");return;}
        // Use the next bubble only when an actual board simulation demonstrates a
        // substantial advantage. First probe is verified through the next screenshot.
        if(swapSupported>=0 && board.next!=0 && board.next!=board.current){
            BoardState swapped=board.copy();swapped.current=board.next;
            TrajectoryPlanner.Shot alternative=TrajectoryPlanner.choose(swapped);
            if(alternative!=null && alternative.score>shot.score+(gap<240?450:850)
                    && alternative.popped+alternative.dropped>=3){
                attemptSwap(board,now,image.getWidth(),image.getHeight());return;
            }
        }
        setStatus((gap<240?"RATUNEK! ":"Gra ")+"strzaly: "+shots+"\n"+shot.reason);
        fire(shot.angle,image.getWidth(),image.getHeight());
        lastShot=now;pendingHash=board.hash;pendingColor=board.current;awaitingResult=true;lastHash=0;stability=0;shots++;
    }
    private void attemptSwap(BoardState board,long now,int width,int height){
        swapWantedColor=board.next;swapOldHash=board.hash;swapAt=now;pendingSwap=true;
        stability=0;setStatus("Probuje zamienic na lepszy kolor...");
        tap(360,1690,width,height);
    }
    private void tap(double canonicalX,double canonicalY,int width,int height){
        float x=(float)(canonicalX*width/BoardState.WIDTH);
        float y=(float)(canonicalY*height/BoardState.HEIGHT);
        Path p=new Path();p.moveTo(x,y);
        GestureDescription gesture=new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p,0,55)).build();
        dispatchGesture(gesture,null,null);
    }
    private void fire(double radians,int width,int height){
        // Short aim vector stays in the game area even for wall-bank shots.
        double reach=275;
        double x=BoardState.SHOOTER_X+Math.sin(radians)*reach;
        double y=BoardState.SHOOTER_Y-Math.cos(radians)*reach;
        float touchX=(float)(x*width/BoardState.WIDTH),touchY=(float)(y*height/BoardState.HEIGHT);
        touchX=Math.max(8,Math.min(width-8,touchX));touchY=Math.max(8,Math.min(height-8,touchY));
        Path p=new Path();p.moveTo(touchX,touchY);
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p,0,55);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture,null,null);
    }
}
