package pl.bubblebot.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Setup screen; all gameplay is autonomous after START. */
public final class MainActivity extends Activity {
    private TextView state;
    private Button start;
    private int dp(int v) {return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s);t.setTextSize(size);t.setTextColor(color);
        t.setPadding(0,dp(8),0,dp(10));return t;
    }
    private Button action(String s) {
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(17);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,dp(8),0,dp(8));b.setLayoutParams(lp);
        return b;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout main=new LinearLayout(this);main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(24),dp(30),dp(24),dp(20));main.setBackgroundColor(0xff170832);
        TextView title=text("BUBBLEBOT PRO",30,0xfff2e6ff);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);main.addView(title);
        main.addView(text("Wersja 0.5 • dokładna siatka • punkty i bezpieczeństwo",16,0xffaab3ff));
        state=text("Sprawdzam usługę…",18,Color.WHITE);main.addView(state);
        Button access=action("1. Włącz dostępność BubbleBot Pro");main.addView(access);
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        start=action("2. START – automatyczne strzały");main.addView(start);
        start.setOnClickListener(v->{
            BotAccessibilityService service=BotAccessibilityService.instance;
            if(service!=null) service.startBot(); else startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            updateStatus();
        });
        Button stop=action("STOP – natychmiast zatrzymaj");main.addView(stop);
        stop.setOnClickListener(v->{BotAccessibilityService service=BotAccessibilityService.instance;
            if(service!=null)service.stopBot(); updateStatus();});
        main.addView(text("Po włączeniu START wróć do gry Bubble Shooter Pro. Na ekranie będzie mały przycisk AUTO/STOP umożliwiający sterowanie bez przełączania aplikacji.",16,0xffecdcff));
        main.addView(text("Bot działa wyłącznie lokalnie, nie zapisuje zrzutów ekranu i nie ma dostępu do Internetu. Nie wykonuje kliknięć, gdy nie rozpoznaje planszy.",14,0xffc7b6d6));
        setContentView(main);
    }
    @Override protected void onResume(){super.onResume();updateStatus();}
    private void updateStatus(){
        if(state==null)return;
        BotAccessibilityService service=BotAccessibilityService.instance;
        state.setText(service==null?"Usługa wyłączona – otwórz ustawienia dostępności":
                service.isRunning()?"AUTO: WŁĄCZONE – otwórz grę":"Usługa aktywna – naciśnij START");
    }
}
