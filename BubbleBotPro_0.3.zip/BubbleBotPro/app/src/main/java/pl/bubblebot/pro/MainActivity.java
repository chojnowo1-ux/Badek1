package pl.bubblebot.pro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);
    LinearLayout ll=new LinearLayout(this);ll.setOrientation(LinearLayout.VERTICAL);ll.setPadding(35,55,35,30);
    TextView t=new TextView(this);t.setTextSize(20);t.setText("BubbleBot Pro 0.5 • Survival\n\n1. Wlacz usluge dostepnosci.\n2. Uruchom Bubble Shooter Pro.\n3. Nacisnij AUTO na nakladce.\n\nBot dziala tylko przy wlaczonym ekranie. Caly obraz jest analizowany lokalnie.\n\nCel testowy: 500 000 pkt (wynik nie jest gwarantowany).");ll.addView(t);
    Button btn=new Button(this);btn.setText("Wlacz dostepnosc");btn.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));ll.addView(btn);
    setContentView(ll);
  }
}
