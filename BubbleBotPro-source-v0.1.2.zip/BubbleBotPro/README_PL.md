# BubbleBot Pro – prototyp 0.1 na Androida

## Co jest zrobione

Aplikacja na Androida 11+ (w tym Androida 16), napisana w Java, bez serwera i roota:

- **Tylko AUTO**: po uruchomieniu wykonuje serię zdjęcie ekranu → rozpoznanie → symulacja 201 kątów z odbiciami → punktacja → wykonanie dotknięcia → ponowna analiza.
- Rozpoznaje kolory: niebieski, zielony, różowy i czerwony oraz aktualną/następną kulkę.
- Buduje siatkę heksagonalną, symuluje połączenia, usunięcia i opadanie kulek.
- Uwzględnia potencjalne strefy 50 / 100 / 250 i wykrywa oznaczenie bonusu x2 (szacowana punktacja).
- Wznawia kolejny mecz tylko po rozpoznaniu konkretnego ekranu wyników ze słowem GRAJ, udokumentowanego na nagraniu.
- Przycisk AUTO/STOP wyświetla się jako nakładka usługi dostępności; w aplikacji są także START i STOP.
- Nie wymaga konta ani Internetu; nie zbiera zawartości elementów dostępności, nie przechowuje i nie wysyła zrzutów ekranu.

## Co przetestowano

Moduły czysto-Javowe skompilowano lokalnie i uruchomiono na dwóch zrzutach oraz 19 klatkach pobranych co 2 sekundy z przekazanego wideo. Wykrywanie wybranych klatek:

- 00:02 – 65 kulek, niebieska w wyrzutni, zielona następna.
- 00:16 – 50 kulek, różowa w wyrzutni i różowa następna; osobno rozpoznano kulkę z x2.
- 00:14 – rozpoznany ekran końca gry z przyciskiem GRAJ.
- Panel powiadomień i ekran przejściowy nie zostały zakwalifikowane jako działająca plansza.

**Ważne:** nie ma testu kompilacji Android SDK ani testu na rzeczywistym Androidzie. Trafność celowania i wynik punktowy nie zostały zweryfikowane przez rozegranie rundy. Symulator przyjmuje szacunkowe promienie, szybkość i zasady punktacji; może wymagać kalibracji po pierwszych testach. To kod źródłowy, nie skompilowane APK.

## Kompilacja APK bez komputera

Opcja 1: AndroidIDE (nie jest już rozwijane; działanie na Androidzie 16 nie jest potwierdzone) lub inne IDE na Androida obsługujące projekty Gradle. Otwórz folder projektu i wybierz `assembleDebug`. Może być potrzebna konfiguracja SDK/Gradle oraz zaakceptowanie dostępu do plików.

Opcja 2: GitHub Actions – dołączono `.github/workflows/build-apk.yml` wykorzystujący chmurową maszynę budującą Androida. Wgraj rozpakowany projekt do własnego repozytorium GitHub, uruchom workflow `Build BubbleBot Pro APK` (lub wypchnij commit na `main`). W sekcji Artifacts będzie `BubbleBotPro-debug-APK` zawierający `app-debug.apk`. *Workflow jest przygotowany, ale nie był uruchomiony.*

Alternatywnie Android Studio na komputerze: otwórz projekt, użyj Build > Build APK(s) (wymaga Android SDK 35, Gradle 8.9, Java 17).

## Instalacja i uruchomienie (po zbudowaniu APK)

1. Zainstaluj `app-debug.apk` na swoim telefonie; Android może poprosić o zgodę na instalację z danego źródła.
2. Uruchom BubbleBot Pro. Wybierz „Włącz dostępność BubbleBot Pro”, następnie w systemowych ustawieniach włącz tę usługę.
3. Jeśli Android blokuje przełącznik z powodu ograniczeń instalacji z zewnętrznego źródła, znajdź BubbleBot Pro → informacje o aplikacji → menu z trzema kropkami → „Zezwalaj na ograniczone ustawienia” (nazwa zależy od producenta i wersji Androida). Nadawaj to uprawnienie wyłącznie aplikacji, której kod rozumiesz i której ufasz.
4. Otwórz Bubble Shooter Pro, upewnij się, że wyświetla się plansza. Naciśnij przycisk `▶ AUTO` w nakładce.
5. `■ STOP` zatrzymuje kolejne zrzuty i dotknięcia. Należy pozostawić grę na wierzchu, z włączonym ekranem.

## Wymagania i ograniczenia

- Android API 30+; aplikacja działa w trybie pionowym i zakłada proporcje ekranu i pozycje obiektów z przesłanego filmu 864×1920, skalowane na rozdzielczość urządzenia.
- Nie korzysta z OCR, AccessibilityService przechwytuje ekran za pośrednictwem `takeScreenshot` i dotyka przez `dispatchGesture`.
- Jeśli Android zablokuje zrzuty ekranu (np. chronione okno), bot nie będzie działać; nie próbuje omijać zabezpieczeń.
- Nieznane layouty gry, reklamy i interfejsy nie powinny być automatycznie obsługiwane. Najpierw przetestuj w zwykłej rozgrywce, zanim uznasz algorytm za gotowy na turniej.
- Automatyzacja może być niezgodna z zasadami organizatora lub gry.

## Struktura kodu

- `BoardDetector.java` – kolory, pozycje, siatka, bonus x2.
- `ShotPlanner.java` – symulacja strzałów z odbiciami i heurystyka punktowa.
- `MenuDetector.java` – kontrolowany restart na udokumentowanym ekranie.
- `BotAccessibilityService.java` – zdjęcia ekranu, gesty i nakładka AUTO/STOP.
- `MainActivity.java` – ekran konfiguracji.
- `tests` – testy obrazów uruchamiane JDK bez Androida.

Przykładowy test desktop (gdy zrzuty są dostępne):

```sh
mkdir -p tests/bin
javac -d tests/bin app/src/main/java/pl/bubblebot/pro/{Board,BoardDetector,ShotPlanner,MenuDetector}.java tests/DetectorTest.java tests/MenuTest.java
java -cp tests/bin DetectorTest /sciezka/do/bubble_35.png
```

## Poprawka 0.1.1

W pliku `build.gradle` dopisano wersję Android Gradle Plugin (`8.7.3`) wymaganą do pobrania w trakcie kompilacji z użyciem Gradle 8.9. Pakiet nadal zawiera kod źródłowy, nie APK.

## Poprawka 0.1.2 — błąd AndroidIDE `./gradlew` nie istnieje

Wersja 0.1.1 omyłkowo nie zawierała pliku `gradlew`, dlatego AndroidIDE kończył budowanie kodem 127.

Wersja 0.1.2 dodaje skrypt `gradlew` oraz `gradle/wrapper/gradle-wrapper.properties`.
Ze względu na brak możliwości dołączenia binarnego JAR w środowisku tworzenia paczki, przy
pierwszym uruchomieniu **skrypt pobierze oficjalny plik Gradle Wrapper JAR 8.9** z repozytorium
Gradle i **sprawdzi jego SHA-256** według https://gradle.org/release-checksums/ .
Następnie oficjalny Wrapper pobierze Gradle 8.9 (ok. 130 MB) i sprawdzi sumę SHA-256 dystrybucji.
Do pierwszej kompilacji niezbędny jest internet oraz dostęp do `raw.githubusercontent.com` i
`services.gradle.org`, JDK 17, Android SDK 35 i poprawne narzędzia AndroidIDE.

**Uruchomienie na telefonie:** zamknij wcześniejszy projekt w AndroidIDE, usuń poprzednią
rozpakowaną wersję lub rozpakuj nową w innym miejscu, wybierz `Open existing project` i wskaż
`BubbleBotPro` — folder, który bezpośrednio zawiera `gradlew`, `settings.gradle` i `app`.
Dotknij Run/Build. Nie otwieraj folderu `app` jako głównego projektu.

**Ograniczenie:** projekt zaktualizowano w zakresie brakującego uruchamiacza Gradle, ale
kompilacja na Androidzie 16 nie została zweryfikowana. Ten ZIP nadal nie jest plikiem APK.
Alternatywnie workflow GitHub Actions dołączony do projektu używa `gradle` bezpośrednio i
nie wymaga tego skryptu.
