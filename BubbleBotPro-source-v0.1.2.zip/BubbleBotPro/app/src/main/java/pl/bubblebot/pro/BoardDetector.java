package pl.bubblebot.pro;

/**
 * Works on raw ARGB frames without OCR or cloud dependencies.
 * Coordinates refer to the 864×1920 capture supplied with the project.
 * Portrait-screen scaling is handled here.
 */
public final class BoardDetector {
    public interface Pixels { int width(); int height(); int argb(int x, int y); }
    public static final class Detection {
        public final Board board;
        public final int current, next;
        public final int count;
        public final double quality;
        Detection(Board board, int current, int next, double quality) {
            this.board=board; this.current=current; this.next=next; this.count=board.occupied; this.quality=quality;
        }
        public boolean playable() { return count >= 12 && count <= 235 && current >= 0 && quality >= 0.25; }
    }
    private final Pixels frame;
    private final double sx, sy;
    public BoardDetector(Pixels frame) {
        this.frame = frame;
        this.sx = frame.width() / 864.0;
        this.sy = frame.height() / 1920.0;
    }
    private int at(double x, double y) {
        int px = (int)Math.round(x*sx), py = (int)Math.round(y*sy);
        if (px<0 || py<0 || px>=frame.width() || py>=frame.height()) return 0xff000000;
        return frame.argb(px,py);
    }
    private int classifySingle(int argb) {
        int r=(argb>>16)&255, g=(argb>>8)&255, b=argb&255;
        if (g > 115 && g > r*1.32 && g > b*1.15) return Board.GREEN;
        if (b > 115 && b > r*1.3 && b > g*1.10 && g>30) return Board.BLUE;
        if (r>110 && b>90 && r>g*1.35 && b>g*1.17 && r>b*0.8) return Board.PINK;
        if (r>140 && r>g*1.5 && r>b*1.27) return Board.RED;
        return Board.EMPTY;
    }
    /** Majority of off-centre interior pixels avoids specular highlights and x2 text. */
    public int colorAt(double x, double y, boolean small) {
        final int[][] offsets = small
                ? new int[][] {{0,0},{-5,1},{5,1},{0,5},{0,-5}}
                : new int[][] {{0,7},{10,6},{-10,6},{12,0},{-12,0},{0,-10},{5,-9},{-5,-9},{0,0}};
        int[] counts = new int[4];
        for (int[] of: offsets) {int c=classifySingle(at(x+of[0], y+of[1])); if(c>=0) counts[c]++;}
        int best=-1, n=0;
        for (int i=0;i<4;i++) if(counts[i]>n) {best=i; n=counts[i];}
        return n>= (small?3:5) ? best : Board.EMPTY;
    }
    private boolean hasX2Label(double x, double y) {
        // White digits in the lower-middle of a bubble; specular shine is at top-left.
        int white=0;
        for(int yy=9; yy<=21; yy+=2) for(int xx=-22; xx<=22; xx+=2){
            int argb=at(x+xx,y+yy); int r=(argb>>16)&255,g=(argb>>8)&255,b=argb&255;
            if(r>165 && g>160 && b>135)white++;
        }
        return white>=7;
    }
    public Detection detect() {
        if(frame.width() < 400 || frame.height() < 750) return new Detection(new Board(285,0),-1,-1,0);
        // Find first row's precise vertical offset and parity from a robust grid alignment score.
        // 35s and 1.5s frames use opposite parities, so neither is hard-coded.
        double bestScore=-1e20, top=280; int phase=0;
        for(int p=0;p<=1;p++) {
            for(int yi=274; yi<=304; yi+=2) {
                double score=0; int seen=0;
                Board candidate = new Board(yi,p);
                for(int r=0;r<10;r++) {
                    for(int c=0;c<Board.COLS;c++) {
                        if(!candidate.valid(r,c)) continue;
                        int color = colorAt(candidate.x(r,c), candidate.y(r), false);
                        if(color>=0) {score += (r<5?2.1:1.0); seen++;}
                    }
                }
                if (seen>0 && score>bestScore) {bestScore=score; top=yi; phase=p;}
            }
        }
        Board b = new Board(top,phase);
        for(int r=0;r<Board.ROWS;r++) {
            for(int c=0;c<Board.COLS;c++) {
                if(!b.valid(r,c) || b.y(r)>1500) continue;
                int v=colorAt(b.x(r,c),b.y(r),false);
                b.cells[r][c]=v;
                if(v>=0) b.occupied++;
                if(v==Board.GREEN) b.bonusX2[r][c]=hasX2Label(b.x(r,c),b.y(r));
            }
        }
        int current = colorAt(416,1724,false);
        int next = colorAt(360,1756,true);
        // A recognisable purple playfield + lower score bar rejects most accidental cross-app captures.
        int purple = at(210,1040), pr=(purple>>16)&255, pg=(purple>>8)&255, pb=purple&255;
        boolean purpleBackground = pb>pr*1.3 && pb>pg*1.8 && pg<70;
        double quality = purpleBackground ? (Math.min(1.0, b.occupied / 26.0)) : 0;
        return new Detection(b,current,next,quality);
    }
}
