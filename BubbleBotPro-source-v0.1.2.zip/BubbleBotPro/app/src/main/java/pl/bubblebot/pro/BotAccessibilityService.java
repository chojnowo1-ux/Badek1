package pl.bubblebot.pro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Uses only the Android Accessibility API: screenshot + one gesture at a time.
 * No persistent image storage, no internet access, no external automation tools.
 */
public final class BotAccessibilityService extends AccessibilityService {
    public static volatile BotAccessibilityService instance;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile boolean running=false;
    private boolean captureInFlight=false, gestureInFlight=false;
    private Button overlay;
    private WindowManager window;
    private long lastSignature=Long.MIN_VALUE;
    private int missed=0;
    private long lastReplayTap=0;
    private int capturedWidth=864, capturedHeight=1920;
    private final Runnable captureRunnable=this::capture;

    public boolean isRunning(){return running;}
    @Override protected void onServiceConnected(){
        super.onServiceConnected();instance=this;showOverlay();
        Log.i("BubbleBot","Accessibility service connected");
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* no window text is collected */ }
    @Override public void onInterrupt() {stopBot();}
    public void startBot() {
        main.post(()->{
            running=true;lastSignature=Long.MIN_VALUE;missed=0;
            setOverlay();main.removeCallbacks(captureRunnable);main.post(captureRunnable);
        });
    }
    public void stopBot(){
        running=false;
        main.post(()->{main.removeCallbacks(captureRunnable);setOverlay();});
    }
    private void schedule(long waitMs){
        if(!running)return;
        main.removeCallbacks(captureRunnable);
        main.postDelayed(captureRunnable,waitMs);
    }
    private void capture(){
        if(!running || captureInFlight || gestureInFlight)return;
        captureInFlight=true;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    captureInFlight=false;
                    HardwareBuffer buffer=result.getHardwareBuffer();
                    Bitmap raw=null,frame=null;
                    try {
                        raw=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());
                        if(raw!=null)frame=raw.copy(Bitmap.Config.ARGB_8888,false);
                    } catch(Exception e){Log.w("BubbleBot","Screenshot convert",e);}
                    finally {buffer.close(); if(raw!=null)raw.recycle();}
                    if(frame==null) {schedule(1100);return;}
                    final Bitmap image=frame;
                    capturedWidth=image.getWidth();capturedHeight=image.getHeight();
                    worker.submit(()->process(image));
                }
                @Override public void onFailure(int code){
                    captureInFlight=false;
                    Log.w("BubbleBot","Screenshot error "+code);
                    // Android enforces a minimum interval between accessibility screenshots.
                    schedule(code==ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT?1250:1750);
                }
            });
        } catch(Exception ex){captureInFlight=false;Log.e("BubbleBot","capture",ex);schedule(1500);}
    }
    private long signature(BoardDetector.Detection d){
        long h=1469598103934665603L;
        for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
            h^=(d.board.cells[r][c]+3);h*=1099511628211L;
        }
        return (h^d.current)*1099511628211L;
    }
    private void process(Bitmap image){
        try {
            if(!running)return;
            BoardDetector.Pixels px=new BoardDetector.Pixels(){
                @Override public int width(){return image.getWidth();}
                @Override public int height(){return image.getHeight();}
                @Override public int argb(int x,int y){return image.getPixel(x,y);}
            };
            BoardDetector.Detection d=new BoardDetector(px).detect();
            if(!d.playable()){
                if(MenuDetector.replayVisible(px) &&
                        android.os.SystemClock.uptimeMillis()-lastReplayTap>8000){
                    lastReplayTap=android.os.SystemClock.uptimeMillis();
                    lastSignature=Long.MIN_VALUE;
                    main.post(()->tapScaled(416,1390,2200));
                    return;
                }
                missed++;main.post(()->schedule(missed>5?2200:1250));return;
            }
            missed=0;
            long state=signature(d);
            if(state==lastSignature){main.post(()->schedule(1650));return;}
            ShotPlanner.Shot shot=new ShotPlanner().choose(d.board,d.current);
            if(shot==null){main.post(()->schedule(1400));return;}
            lastSignature=state;
            Log.i("BubbleBot",String.format(java.util.Locale.US,"balls=%d angle=%.1f removed=%d dropped=%d predicted=%.1f",d.count,shot.angleDegrees,shot.removed,shot.dropped,shot.score));
            main.post(()->fire(shot));
        }catch(Exception ex){Log.e("BubbleBot","analysis",ex);main.post(()->schedule(1600));}
        finally{image.recycle();}
    }
    private void fire(ShotPlanner.Shot shot){
        if(!running)return;
        float x=(float)(shot.targetX*capturedWidth/864.0);
        float y=(float)(shot.targetY*capturedHeight/1920.0);
        if(x<1 || x>capturedWidth-1 || y<180 || y>capturedHeight-70){schedule(1300);return;}
        gestureAt(x,y,1150);
    }
    private void tapScaled(double x,double y,long afterMs) {
        if(!running)return;
        gestureAt((float)(x*capturedWidth/864.0),(float)(y*capturedHeight/1920.0),afterMs);
    }
    private void gestureAt(float x,float y,long afterMs){
        if(!running || gestureInFlight)return;
        Path p=new Path();p.moveTo(x,y);
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p,0,75);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(stroke).build();
        gestureInFlight=true;
        boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){gestureInFlight=false;schedule(afterMs);}
            @Override public void onCancelled(GestureDescription g){gestureInFlight=false;schedule(1300);}
        },main);
        if(!accepted){gestureInFlight=false;schedule(1400);}
    }
    private void showOverlay(){
        if(overlay!=null)return;
        window=(WindowManager)getSystemService(WINDOW_SERVICE);
        overlay=new Button(this);
        overlay.setTextColor(Color.WHITE);overlay.setTextSize(13);overlay.setAllCaps(false);
        overlay.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        int w=(int)(108*getResources().getDisplayMetrics().density), h=(int)(48*getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(w,h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.BOTTOM | Gravity.RIGHT;
        lp.x=(int)(10*getResources().getDisplayMetrics().density);
        lp.y=(int)(82*getResources().getDisplayMetrics().density);
        overlay.setOnClickListener(v->{if(isRunning())stopBot();else startBot();});
        setOverlay();
        try {window.addView(overlay,lp);}catch(Exception e){Log.e("BubbleBot","overlay",e);overlay=null;}
    }
    private void setOverlay(){if(overlay==null)return;overlay.setText(running?"■ STOP":"▶ AUTO");
        overlay.setBackgroundTintList(android.content.res.ColorStateList.valueOf(running?0xffcc2964:0xff3f9c43));}
    @Override public void onDestroy(){
        running=false;main.removeCallbacks(captureRunnable);
        if(overlay!=null && window!=null){try{window.removeView(overlay);}catch(Exception ignored) {}}
        worker.shutdownNow();instance=null;super.onDestroy();
    }
}
