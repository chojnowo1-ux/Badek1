package pl.bubblebot.pro;

import java.util.ArrayDeque;

/**
 * Enumerates 201 aim angles with side-wall bounces, snaps to the nearest
 * connected empty hex cell, then scores same-colour removal and detachment.
 * The point weights are preliminary estimates, not proven game rules.
 */
public final class ShotPlanner {
    public static final class Shot {
        public final double angleDegrees, targetX, targetY, score;
        public final int removed, dropped, bounceCount;
        Shot(double angleDegrees, double targetX,double targetY,double score,int removed,int dropped,int bounces) {
            this.angleDegrees=angleDegrees; this.targetX=targetX; this.targetY=targetY;
            this.score=score; this.removed=removed; this.dropped=dropped;this.bounceCount=bounces;
        }
    }
    private static final double SHOT_X=416, SHOT_Y=1721, RADIUS_COLLISION=60.0;
    private static final int[][] offsets = new int[6][2];
    public Shot choose(Board board, int ball) {
        if(ball<0) return null;
        Shot best=null;
        for(double angle=-80; angle<=80; angle+=0.8) {
            Shot s=simulate(board,ball,angle);
            if(s!=null && (best==null || s.score>best.score)) best=s;
        }
        return best;
    }
    private Shot simulate(Board src, int ball, double angle) {
        double radians=Math.toRadians(angle), dx=Math.sin(radians), dy=-Math.cos(radians);
        double x=SHOT_X, y=SHOT_Y, impactX=0,impactY=0;
        int bounced=0; boolean collided=false;
        for(int step=0;step<390;step++) {
            x += dx * 4.1; y += dy * 4.1;
            if(x<32){x=64-x;dx=-dx;bounced++;}
            if(x>832){x=1664-x;dx=-dx;bounced++;}
            if(y<=src.topY) {impactX=x;impactY=src.topY;collided=true;break;}
            // Cutoff by occupied balls. Scan only the row and its neighbours.
            int row=(int)Math.round((y-src.topY)/Board.SPACING_Y);
            boolean hit=false;
            for(int r=Math.max(0,row-2);r<=Math.min(Board.ROWS-1,row+2) && !hit;r++) {
                for(int c=0;c<Board.COLS;c++) {
                    if(src.cells[r][c]<0) continue;
                    double ddx=src.x(r,c)-x, ddy=src.y(r)-y;
                    if(ddx*ddx+ddy*ddy < RADIUS_COLLISION*RADIUS_COLLISION) {hit=true;break;}
                }
            }
            if(hit){impactX=x;impactY=y;collided=true;break;}
        }
        if(!collided)return null;
        int sr=-1,sc=-1;double minD=Double.POSITIVE_INFINITY;
        for(int r=0;r<Board.ROWS;r++) {
            if(src.y(r)>impactY+95 || src.y(r)<impactY-95)continue;
            for(int c=0;c<Board.COLS;c++) {
                if(src.cells[r][c]!=Board.EMPTY || !src.adjacentOccupied(r,c))continue;
                double xx=src.x(r,c),yy=src.y(r), dd=(xx-impactX)*(xx-impactX)+(yy-impactY)*(yy-impactY);
                if(dd<minD) {sr=r;sc=c;minD=dd;}
            }
        }
        if(sr<0)return null;
        Board board=src.copy();board.cells[sr][sc]=ball;
        boolean[][] hit=new boolean[Board.ROWS][Board.COLS];
        ArrayDeque<int[]> q=new ArrayDeque<>();q.add(new int[]{sr,sc});hit[sr][sc]=true;
        int group=0;
        while(!q.isEmpty()) {
            int[] a=q.removeFirst();group++;
            int n=board.neighbours(a[0],a[1],offsets);
            for(int i=0;i<n;i++){
                int rr=offsets[i][0],cc=offsets[i][1];
                if(!hit[rr][cc] && board.cells[rr][cc]==ball){hit[rr][cc]=true;q.add(new int[]{rr,cc});}
            }
        }
        int removed=0,dropped=0;
        boolean gotX2=false;
        double dropWeighted=0;
        if(group>=3) {
            for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++) {
                if(hit[r][c]){
                    if(board.bonusX2[r][c])gotX2=true;
                    board.cells[r][c]=Board.EMPTY;removed++;}
            }
            boolean[][] connected=new boolean[Board.ROWS][Board.COLS];
            for(int c=0;c<Board.COLS;c++) if(board.cells[0][c]>=0){connected[0][c]=true;q.add(new int[]{0,c});}
            while(!q.isEmpty()) {
                int[] a=q.removeFirst();int n=board.neighbours(a[0],a[1],offsets);
                for(int i=0;i<n;i++){
                    int rr=offsets[i][0],cc=offsets[i][1];
                    if(!connected[rr][cc] && board.cells[rr][cc]>=0){connected[rr][cc]=true;q.add(new int[]{rr,cc});}
                }
            }
            for(int r=0;r<Board.ROWS;r++)for(int c=0;c<Board.COLS;c++){
                if(board.cells[r][c]>=0 && !connected[r][c]){
                    dropped++; double xx=board.x(r,c);
                    double zone = xx<172 || xx>=660 ? 50 : xx<340 || xx>=496 ? 100 : 250;
                    dropWeighted += zone/100.0;
                }
            }
        }
        // A small tie-break rewards placing near a same-colour neighbour and closer to ceiling.
        double score=(removed*95 + dropped*115 + dropWeighted*35)*(gotX2?2.0:1.0);
        if(removed==0)score=-55 + Math.min(35,group*14) - sr*0.6;
        score -= bounced*1.8;
        score -= Math.abs(angle)*0.025;
        // We output a tap on a point along the outgoing ray, not at the impact cell.
        // This preserves a rebound trajectory even when the target is behind another cluster.
        double tapY=690;
        double distance=(SHOT_Y-tapY)/Math.cos(radians);
        double tapX=SHOT_X+Math.sin(radians)*distance;
        // If the projected tap exits the display, use a point closer to the launcher.
        if(tapX<100 || tapX>764){distance=200;tapY=SHOT_Y-200*Math.cos(radians);tapX=SHOT_X+200*Math.sin(radians);}
        return new Shot(angle,tapX,tapY,score,removed,dropped,bounced);
    }
}
